﻿using Lab7ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Lab7ClassLibraryTests
{
    [TestClass]
    public class AlphabetTests
    {
        [TestMethod]
        public void GetAlphaTest()
        {
            int a = 1;
            int a2 = 5;
            int a3 = 26;
            char expected = 'A';
            char expected2 = 'E';
            char expected3 = 'Z';

            Alphabet alphabet = new Alphabet();
            char actual = alphabet.GetAlpha(a);
            char actual2 = alphabet.GetAlpha(a2);
            char actual3 = alphabet.GetAlpha(a3);

            Assert.AreEqual(expected, actual);
            Assert.AreEqual(expected2, actual2);
            Assert.AreEqual(expected3, actual3);
        }

        [TestMethod]
        public void GetAlphaInvalidDataTest()
        {
            int a = 0;
            int a2 = -5;
            int a3 = 27;
            Alphabet alphabet = new Alphabet();

            Assert.ThrowsException<ArgumentException>(() =>
                alphabet.GetAlpha(a));
            Assert.ThrowsException<ArgumentException>(() =>
                alphabet.GetAlpha(a2));
            Assert.ThrowsException<ArgumentException>(() =>
                alphabet.GetAlpha(a3));
        }
    }
}
