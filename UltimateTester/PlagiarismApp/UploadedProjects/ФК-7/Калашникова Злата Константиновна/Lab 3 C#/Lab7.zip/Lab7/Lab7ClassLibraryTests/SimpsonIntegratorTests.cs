﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Lab6_Integration.Integration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7ClassLibraryTests
{
    [TestClass]
    public class SimpsonIntegratorTests
    {
        [TestMethod]
        public void IntegrateTest()
        {
            double precision = 0.01;
            SimpsonIntegrator si = new SimpsonIntegrator();
            si.IntegratingHandler += TestFunction;
            double x0 = 0;
            double x1 = 5;
            int n = 100;

            double expected = 43.296;
            double actual = si.Integrate(x0, x1, n);
            Assert.AreEqual(expected, actual, precision);
        }

        [TestMethod]
        public void IntegrateInvalidDataTest()
        {
            //double precision = 0.01;
            SimpsonIntegrator si = new SimpsonIntegrator();
            si.IntegratingHandler += TestFunction;

            double x0 = 0;
            double x1 = 5;
            int n = 99;
            Assert.ThrowsException<ArgumentException>(() =>
                si.Integrate(x0, x1, n));
            double x02 = 5;
            double x12 = 0;
            int n2 = 50;
            Assert.ThrowsException<ArgumentException>(() =>
                si.Integrate(x02, x12, n2));
            double x03 = 5;
            double x13 = 0;
            int n3 = -50;
            Assert.ThrowsException<ArgumentException>(() =>
                si.Integrate(x03, x13, n3));
        }


        private double TestFunction(double x)
        {
            return 5 * x * Math.Abs(Math.Sin(x));
        }
    }
}
