﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7ClassLibrary
{
    public class PositiveNumber
    {
        public int Sum(string number)
        {
            int sum = 0;
            for (int i = 0; i < number.Length; i++)
            {
                if (char.IsDigit(number[i]))
                {
                    sum += ToInt(number[i]);
                }
                else throw new ArgumentException();
            }
            return sum;
        }

        private int ToInt(char c)
        {
            return (c - '0');
        }
    }
}
