﻿using Lab7ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Lab7ClassLibraryTests
{
    [TestClass]
    public class QuadricEquationTests
    {
        [TestMethod]
        public void GetRootsTest()
        {
            QuadricEquation qe = new QuadricEquation();
            double precision = 0.01;
            double a = 1;
            double b = -5;
            double c = 6;
            double[] expected = { 3, 2 };
            double a2 = 1;
            double b2 = -10;
            double c2 = 25;
            double[] expected2 = { 5 };
            double a3 = 1;
            double b3 = -3;
            double c3 = 0;
            double[] expected3 = { 0, 3 };
            double a4 = 1;
            double b4 = 0;
            double c4 = -6;
            double[] expected4 = { -Math.Sqrt(6), Math.Sqrt(6) };

            double[] actual = qe.GetRoots(a, b, c);
            double[] actual2 = qe.GetRoots(a2, b2, c2);
            double[] actual3 = qe.GetRoots(a3, b3, c3);
            double[] actual4 = qe.GetRoots(a4, b4, c4);
            // 1
            Assert.AreEqual(expected[0], actual[0], precision);
            Assert.AreEqual(expected[1], actual[1], precision);
            // 2
            Assert.AreEqual(expected2[0], actual2[0], precision);
            // 3
            Assert.AreEqual(expected3[0], actual3[0], precision);
            Assert.AreEqual(expected3[1], actual3[1], precision);
            // 4
            Assert.AreEqual(expected4[0], actual4[0], precision);
            Assert.AreEqual(expected4[1], actual4[1], precision);
            
        }

        [TestMethod]
        public void GetRootsInvalidDataTest()
        {
            QuadricEquation qe = new QuadricEquation();
            double a3 = 1;
            double b3 = -5;
            double c3 = 7;
            //double[] expected3 = null;
            double a6 = 2;
            double b6 = 0;
            double c6 = 6;
            //double[] expected6 = null;
            // 3
            Assert.ThrowsException<ArgumentException>(() =>
                qe.GetRoots(a3, b3, c3));
            //Assert.AreEqual(expected3, actual3);
            // 6
            Assert.ThrowsException<ArgumentException>(() =>
                qe.GetRoots(a6, b6, c6));
            //Assert.AreEqual(expected6, actual6);
        }
    }
}