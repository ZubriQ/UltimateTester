﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7ClassLibrary
{
    public class QuadricEquation
    {
        public double[] GetRoots(double a, double b, double c)
        {
            double[] result = null;
            // ax^2+bx+c=0
            if (a != 0 && b != 0 && c != 0) // if it is a complete equation
            {
                double D = b * b - 4 * a * c;
                if (D > 0) // 2 roots
                {
                    double x1 = (-b + D) / 2 * a;
                    double x2 = (-b - D) / 2 * a;
                    result = new double[]{ x1, x2 };
                    return result;
                }
                else if (D < 0) // 0 roots
                {
                    throw new ArgumentException();
                }
                else if (D == 0) // 1 root
                {
                    double x1 = (-b + D) / 2 * a;
                    result = new double[] { x1 };
                    return result;
                }
            }
            // ax^2+bx=0
            else if (a != 0 && b != 0 && c == 0) // if it's an incomplete equation
            {
                double x1 = 0;
                double x2 = -b / a;
                result = new double[] { x1, x2 };
                return result;
            }
            // ax^2+c=0
            else if (a != 0 && b == 0 && c != 0)
            {
                if (a * c < 0)
                {
                    c = -c;
                    double x1 = -Math.Sqrt(c);
                    double x2 = Math.Sqrt(c);
                    result = new double[] { x1, x2 };
                    return result;
                }
                //else return result;
            }
            // ax^2=0
            //else if (a != 0 && b == 0 && c == 0)
            //{
            //    result = new double[] { 0 };
            //    return result;
            //}
            throw new ArgumentException();
        }
    }
}
