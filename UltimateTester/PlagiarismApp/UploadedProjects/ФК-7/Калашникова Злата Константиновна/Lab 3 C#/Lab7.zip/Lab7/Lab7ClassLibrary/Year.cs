﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7ClassLibrary
{
    public class Year
    {
        public int GetDays(int year)
        {
            if (year < 1)
                throw new ArgumentException();
            if (year % 400 == 0)
                return 366;
            else if (year % 100 == 0)
                return 365;
            else if (year % 4 == 0)
                return 366;
            else
                return 365;
        }
    }
}
