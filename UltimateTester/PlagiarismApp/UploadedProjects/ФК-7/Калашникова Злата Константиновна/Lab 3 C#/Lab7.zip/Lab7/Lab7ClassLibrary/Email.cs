﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lab7ClassLibrary
{
    public class Email
    {
        private string _emailPattern =
            @"^[a-zA-Z][a-zA-Z0-9\-_+.]{0,254}\@(([a-zA-Z][a-zA-Z0-9\-]{0,}))(\.[a-zA-Z]{2,})+$";

        private Regex _regex;

        public Email()
        {
            _regex = new Regex(_emailPattern);
        }

        public bool IsCorrect(string email)
        {
            if (_regex.IsMatch(email))
                return true;
            else throw new ArgumentException();
        }
    }
}
