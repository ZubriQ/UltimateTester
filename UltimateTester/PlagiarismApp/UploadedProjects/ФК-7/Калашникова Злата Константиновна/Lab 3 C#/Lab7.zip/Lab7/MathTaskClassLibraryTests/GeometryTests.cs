﻿using MathTaskClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace MathTaskClassLibraryTests
{
    [TestClass]
    public class GeometryTests
    {
        [TestMethod]
        public void RectangleAreaTest()
        {
            int a = 3;
            int b = 4;
            int expected = 12;

            Geometry geometry = new Geometry();
            int actual = geometry.RectangleArea(a, b);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void RectangleAreaInvalidDataTest1()
        {
            bool catched = false;
            try
            {
                int a = -4;
                int b = 10;

                Geometry geometry = new Geometry();
                geometry.RectangleArea(a, b);
            }
            catch (ArgumentException ex)
            {
                catched = true;
            }
            Assert.IsTrue(catched, "invalid data not processed");
        }

        [TestMethod]
        public void RectangleAreaInvalidDataTest2()
        {
            int a = -4;
            int b = 10;
            Geometry geometry = new Geometry();
            Assert.ThrowsException<ArgumentException>(() =>
                geometry.RectangleArea(a, b));
        }
    }
}
