﻿using Lab7ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Lab7ClassLibraryTests
{
    [TestClass]
    public class YearTests
    {
        [TestMethod]
        public void GetDaysTest()
        {
            Year y = new Year();
            int year = 1;
            int year2 = 4;
            int year3 = 200;
            int year4 = 800;
            int year5 = 900;
            int year6 = Int32.MaxValue;
            int expectedNotLeap = 365;
            int expectedLeap = 366;

            int actual = y.GetDays(year);
            Assert.AreEqual(expectedNotLeap, actual);
            int actual2 = y.GetDays(year2);
            Assert.AreEqual(expectedLeap, actual2);
            int actual3 = y.GetDays(year3);
            Assert.AreEqual(expectedNotLeap, actual3);
            int actual4 = y.GetDays(year4);
            Assert.AreEqual(expectedLeap, actual4);
            int actual5 = y.GetDays(year5);
            Assert.AreEqual(expectedNotLeap, actual5);
            int actual6 = y.GetDays(year6);
            Assert.AreEqual(expectedNotLeap, actual6);
        }

        [TestMethod]
        public void GetDaysInvalidDataTest()
        {
            Year y = new Year();
            int year = 0;
            int year2 = -5;
            int year3 = Int32.MinValue;

            Assert.ThrowsException<ArgumentException>(() =>
                y.GetDays(year));
            Assert.ThrowsException<ArgumentException>(() =>
                y.GetDays(year2));
            Assert.ThrowsException<ArgumentException>(() =>
                y.GetDays(year3));
        }
    }
}
