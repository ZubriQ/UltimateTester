﻿using Lab7ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace Lab7ClassLibraryTests
{
    [TestClass]
    public class PositiveNumberTests
    {
        [TestMethod]
        public void SumTest()
        {
            PositiveNumber pn = new PositiveNumber();
            string test = "123";
            string test2 = "55551";
            int expected = 6;
            int expected2 = 21;

            int actual = pn.Sum(test);
            Assert.AreEqual(expected, actual);
            int actual2 = pn.Sum(test2);
            Assert.AreEqual(expected2, actual2);
        }

        [TestMethod]
        public void SumInvalidDataTest()
        {
            PositiveNumber pn = new PositiveNumber();
            string test = ".123";
            string test2 = "555d51";

            Assert.ThrowsException<ArgumentException>(() =>
                pn.Sum(test));
            Assert.ThrowsException<ArgumentException>(() =>
                pn.Sum(test2));
        }
    }
}
