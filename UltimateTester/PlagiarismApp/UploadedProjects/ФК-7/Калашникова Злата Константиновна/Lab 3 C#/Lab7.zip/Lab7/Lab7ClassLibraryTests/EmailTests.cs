﻿using Lab7ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Lab7ClassLibraryTests
{
    [TestClass]
    public class EmailTests
    {
        [TestMethod]
        public void CheckTest()
        {
            Email em = new Email();
            string email = "test@test.test";
            bool expected = true;
            bool actual = em.IsCorrect(email);
            Assert.AreEqual(expected, actual);

            string email2 = "firstname.lastname@example.com";
            bool actual2 = em.IsCorrect(email2);
            Assert.AreEqual(expected, actual2);

            string email3 = "he-hm@n05mail.dd";
            bool actual3 = em.IsCorrect(email3);
            Assert.AreEqual(expected, actual3);
        }

        [TestMethod]
        public void CheckInvalidDataTest()
        {
            Email em = new Email();
            string email = "tef@stf@test.tes";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email));
            string email2 = "a@b!ds.cf";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email2));
            string email3 = "joen[]otok@sixpack.com";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email3));
            string email4 = "a@b.c";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email4));
            string email5 = "@jungle.org";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email5));
            string email6 = "ddfhgdsfgd6fgsdfg6sdfg6sdfg57sdfg54sgs65dfg4sd6h" +
                "fg4sd6gsdgsdfg4sdfg4sggsdg4dsg4ds4gg54sdg4sdgsdg4sdf6gsdfgdf" +
                "gewr76wer6wer6wersd6f5s6f5sd6f5sd6f5sd6f5s6df5sd6f2yu34tyu23" +
                "4t2u3y4t23uy4t23u4y234g234f23gh4f23hg23f4hg23f42h3g4fh23f4h2" +
                "34fh23gf423hg4f23hgf423ghf423hg@mail.ru"; // too long
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email6));
            string email7 = "zeus!deusnotok@gmail.com";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email7));
            string email8 = "<joenotok@sixpack.com";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email8));
            string email9 = "notok@mail.example.com:joe@sixpack.com";
            Assert.ThrowsException<ArgumentException>(() => em.IsCorrect(email9));
            
        }
    }
}
