﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Lab9_Photo_studio
{
    internal class PhotoFileWorker : FileWorker
    {
        private readonly string[] _filters;
        private SortOption _sortBy;

        public DirectoryInfo FolderFrom { get; set; }
        public DirectoryInfo FolderTo { get; set; }
        public DirectoryInfo FolderWatermarks { get; set; }

        public List<FileInfo> Files { get; set; }
        public List<GPSMetadata> ImagesMetadata { get; set; }
        public static List<GPSMetadata> CitiesMetadata { get; set; }

        public EventHandler<FileWorkerEventArgs> OnDuplicateRemove;
        public EventHandler<FileWorkerEventArgs> OnFinish;

        public PhotoFileWorker() 
        {
            _filters = new string[] { "jpg", "jpeg", "png", "gif", "tiff", "bmp", "svg" };
            ImagesMetadata = new List<GPSMetadata>();
            InitializeCitiesMetadataFromLocalFile();

            // Test: Should be equal to 347.3 Km.
            //var d = GPSMetadata.HaversineDistance(new GPSMetadata("Test1", 41.507483, -99.436554),
            //    new GPSMetadata("Test2", 38.504048, -98.315949));
        }

        void InitializeCitiesMetadataFromLocalFile()
        {
            //List<GPSMetadata> metadata = JsonConvert.DeserializeObject<List<GPSMetadata>>(File.ReadAllText("cities.json"));
            using (StreamReader file = File.OpenText("cities.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                CitiesMetadata = (List<GPSMetadata>)serializer.Deserialize(file, typeof(List<GPSMetadata>));
            }
        }

        public bool GetPhotoFiles(string from, string to)
        {
            FolderFrom = new DirectoryInfo(from);
            FolderTo = new DirectoryInfo(to);
            FolderWatermarks = new DirectoryInfo(Path.Combine(to, "Watermarks"));
            Files = new List<FileInfo>();
            ImagesMetadata = new List<GPSMetadata>();

            try
            {
                foreach (var filter in _filters)
                    Files.AddRange(FolderFrom.GetFiles(string.Format("*.{0}", filter),
                        SearchOption.AllDirectories));
                return true; // Successful Completion.
            }
            catch (DirectoryNotFoundException)
            {
                return false; // Unsuccessful Completion.
            }
        }

        public void DeleteDuplicatePaths()
        {
            for (int i = 0; i < Files.Count; i++)
                for (int j = 0; j < Files.Count; j++)
                    if (i != j)
                    {
                        if (CompareImages(Files[i], Files[j])) 
                        {
                                Files.Remove(Files[j]);
                                RaiseDuplicateRemoveEvent(Files[j].Name);
                        }
                    }
        }

        // a. File name & File size.
        private bool CompareImages(FileInfo file1, FileInfo file2) 
        {
            return (file1.Name == file2.Name) && (file1.Length == file2.Length);
        }

        public void SortByCreationDate()
        {
            Files = Files.OrderBy(x => x.CreationTime).ToList();
        }

        private void CreateFolders(List<Date> folders)
        {
            for (int i = 0; i < folders.Count; i++) // Create folders in the directory.
            {
                InitializeCopyPath(folders[i]);
            }
        }

        // Initializes the copy path
        private void InitializeCopyPath(Date folder)
        {
            string path, watermarkPath;
            switch (_sortBy)
            {
                case SortOption.Day:
                    path = Path.Combine(FolderTo.FullName, "Sorted by Day", folder.GetDay());
                    watermarkPath = Path.Combine(FolderTo.FullName, FolderWatermarks.Name, "Sorted by Day", folder.GetDay());
                    CreateDirectories(path, watermarkPath);
                    break;
                case SortOption.Month:
                    path = Path.Combine(FolderTo.FullName, "Sorted by Month", folder.GetMonth());
                    watermarkPath = Path.Combine(FolderTo.FullName, FolderWatermarks.Name, "Sorted by Month", folder.GetMonth());
                    CreateDirectories(path, watermarkPath);
                    break;
                case SortOption.Week:
                    path = Path.Combine(FolderTo.FullName, "Sorted by Week", folder.GetWeek());
                    watermarkPath = Path.Combine(FolderTo.FullName, FolderWatermarks.Name, "Sorted by Week", folder.GetWeek());
                    CreateDirectories(path, watermarkPath);
                    break;
            }
        }

        void CreateDirectories(string path, string watermarkPath)
        {
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            if (!Directory.Exists(watermarkPath))
                Directory.CreateDirectory(watermarkPath);
        }

        public void CopyFiles(SortOption sortBy)
        {
            _sortBy = sortBy;
            List<Date> folders = new List<Date>();
            // Create folders.
            InitializeWeekFolders(folders);
            CreateFolders(folders);
            // Copy files & watermarked files.
            CopyFiles();
            MakeWatermarks();
            RaiseFinishEvent(Files.Count);
        }

        void MakeWatermarks()
        {
            for (int i = 0; i < Files.Count; i++)
            {
                Date date = new Date(Files[i].CreationTime);
                string folderName = InitializeSortedFolderName(date);
                string copyTo = Path.Combine(FolderWatermarks.FullName, folderName, Files[i].Name);
                Watermark(Files[i].FullName, copyTo);
            }
        }

        void CopyFiles()
        {
            for (int i = 0; i < Files.Count; i++)
            {
                // Copy a file.
                Date date = new Date(Files[i].CreationTime);
                string folderName = InitializeSortedFolderName(date);
                string copyTo = Path.Combine(FolderTo.FullName, folderName, Files[i].Name);
                Copy(Files[i].FullName, copyTo); 

                // Add metadata of the copying file.
                var metadata = new GPSMetadata(Files[i]);
                if (metadata.NearestCity != "Unknown")
                {
                    SetNearestCities(metadata);
                }
                ImagesMetadata.Add(metadata);
            }
        }

        void SetNearestCities(GPSMetadata metadata)
        {
            double min = double.MaxValue;
            string cityName = null;
            foreach (var city in CitiesMetadata)
            {
                var val = GPSMetadata.HaversineDistance(metadata, city);
                if (val < min)
                {
                    min = val;
                    cityName = city.ObjectName;
                }
            }
            metadata.NearestCity = cityName;
        }

        private string InitializeSortedFolderName(Date date)
        {
            string folderName = null;
            switch (_sortBy)
            {
                case SortOption.Day:
                    folderName = Path.Combine("Sorted by Day\\", date.GetDay());
                    break;
                case SortOption.Week:
                    folderName = Path.Combine("Sorted by Week\\", date.GetWeek());
                    break;
                case SortOption.Month:
                    folderName = Path.Combine("Sorted by Month\\", date.GetMonth());
                    break;
            }
            return folderName;
        }

        private void InitializeWeekFolders(List<Date> folders)
        {
            for (int i = 0; i < Files.Count; i++) // Find out what folders to create.
                CreateFolder(folders, i);
        }

        private void CreateFolder(List<Date> folders, int index)
        {
            Date folder = new Date(Files[index].CreationTime);
            switch (_sortBy)
            {
                case SortOption.Day:
                    CreateDayFolder(folders, folder);
                    break;
                case SortOption.Week:
                    CreateWeekFolder(folders, folder);
                    break;
                case SortOption.Month:
                    CreateMonthFolder(folders, folder);
                    break;
            }
        }

        private void CreateDayFolder(List<Date> folders, Date folder)
        {
            if (!folders.Any(f => (f.Day == folder.Day) &&
                                  (f.Month == folder.Month) &&
                                  (f.Year == folder.Year)))
                folders.Add(folder);
        }

        private void CreateWeekFolder(List<Date> folders, Date folder)
        {
            if (!folders.Any(f => (f.Week == folder.Week) &&
                                  (f.Month == folder.Month) &&
                                  (f.Year == folder.Year)))
                folders.Add(folder);
        }

        private void CreateMonthFolder(List<Date> folders, Date folder)
        {
            if (!folders.Any(f => (f.Month == folder.Month) &&
                                          (f.Year == folder.Year)))
                folders.Add(folder);
        }

        #region Raise On DuplicateRemove & Finish events
        private void RaiseDuplicateRemoveEvent(string removedFile)
        {
            if (OnDuplicateRemove != null)
            {
                FileWorkerEventArgs args = new FileWorkerEventArgs()
                {
                    RemovedFile = removedFile
                };
                OnDuplicateRemove(this, args);
            }
        }

        private void RaiseFinishEvent(int copiedFilesCount)
        {
            if (OnFinish != null)
            {
                FileWorkerEventArgs args = new FileWorkerEventArgs()
                {
                    FilesCount = copiedFilesCount
                };
                OnFinish(this, args);
            }
        }
        #endregion
    }
}