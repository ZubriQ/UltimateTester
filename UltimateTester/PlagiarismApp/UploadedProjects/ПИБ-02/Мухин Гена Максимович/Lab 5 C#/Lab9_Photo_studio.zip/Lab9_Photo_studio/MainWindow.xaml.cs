﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab9_Photo_studio
{
    public partial class MainWindow : Window
    {
        public string PathLoadFrom { get { return txtLoadFrom.Text; } }
        public string PathSortTo { get { return txtSortTo.Text; } }

        private PhotoFileWorker _fileWorker;

        public MainWindow()
        {
            InitializeComponent();
            InitializeStandardPaths();
            _fileWorker = new PhotoFileWorker();
            InitializeEventSubscriptions();
        }

        private void InitializeEventSubscriptions()
        {
            _fileWorker.OnFileCopy += LogCopiedFile;
            _fileWorker.OnCopyError += LogCopyError;
            _fileWorker.OnDuplicateRemove += LogRemovedFile;
            _fileWorker.OnFinish += UpdateSortingStatus;
        }

        // Load photographs.
        private void btnLoadPhotos_Click(object sender, RoutedEventArgs e)
        {
            bool isSuccessful = _fileWorker.GetPhotoFiles(PathLoadFrom, PathSortTo);
            if (isSuccessful)
            {
                ChangeLoadStatusState();
                _fileWorker.DeleteDuplicatePaths();
                _fileWorker.SortByCreationDate();
            }
            else
            {
                lblLoadStatus.Content = $"such folder does not exist.";
                lblLoadStatus.Foreground = new SolidColorBrush(Colors.Red);
            }
        }

        private void ChangeLoadStatusState()
        {
            if (_fileWorker.Files.Count > 0)
            {
                EnableSortingButtons();
                lblLoadStatus.Content = $"files found: {_fileWorker.Files.Count}.";
                lblLoadStatus.Foreground = new SolidColorBrush(Colors.Green);
                lblSortingStatus.Content = "choose sorting algorithm . . .";
                //btnLoadPhotos.IsEnabled = false;
            }
            else
            {
                FilesNotFound(lblLoadStatus);
            }
        }

        private void FilesNotFound(Label label)
        {
            label.Content = $"the folder is empty.";
            label.Foreground = new SolidColorBrush(Colors.Red);
        }

        private void UpdateSortingStatus(object sender, FileWorkerEventArgs e)
        {
            lblSortingStatus.Content = $"";
            if (e.FilesCount > 0)
            {
                lblSortingStatus.Foreground = new SolidColorBrush(Colors.Green);
                lblSortingStatus.Content = $"files copied: {e.FilesCount}.";
            }
            else
                FilesNotFound(lblSortingStatus);
        }

        private void LogCopiedFile(object sender, FileWorkerEventArgs e)
        {
            Log($"\t[Copied From]:\t{e.From}\n\t[Copied To]:\t{e.To}\n");
        }

        private void LogCopyError(object sender, FileWorkerEventArgs e)
        {
            Log($"\t[Error]: {e.CopyError} [Was copying from]: {e.From} [To]: {e.To}\n");
        }

        private void LogRemovedFile(object sender, FileWorkerEventArgs e)
        {
            Log($"\t[File removed]:\t{e.RemovedFile}\n");
        }

        private void Log(string msg)
        {
            txtConsole.Text += msg;
        }

        #region Sorting
        private void btnSortByDay_Click(object sender, RoutedEventArgs e)
        {
            _fileWorker.CopyFiles(SortOption.Day);
        }

        private void btnSortByWeek_Click(object sender, RoutedEventArgs e)
        {
            _fileWorker.CopyFiles(SortOption.Week);
        }

        private void btnSortByMonth_Click(object sender, RoutedEventArgs e)
        {
            _fileWorker.CopyFiles(SortOption.Month);
        }
        #endregion

        void EnableSortingButtons()
        {
            btnSortByDay.IsEnabled = true;
            btnSortByWeek.IsEnabled = true;
            btnSortByMonth.IsEnabled = true;
        }

        void InitializeStandardPaths()
        {
            txtLoadFrom.Text = @"D:\PhotoStudio";
            txtSortTo.Text = @"D:\PhotoStudioSorted";
        }

        // Test cities data.
        void CreateCitiesJson()
        {
            List<GPSMetadata> Cities = new List<GPSMetadata>();
            Cities.Add(new GPSMetadata("Novosibirsk", 54.9833, 82.8964));
            Cities.Add(new GPSMetadata("Moscow", 55.7558, 37.6173));
            Cities.Add(new GPSMetadata("Barnaul", 53.3497, 83.7836));
            Cities.Add(new GPSMetadata("Omsk", 54.9914, 73.3645));
            Cities.Add(new GPSMetadata("Krasnoyarsk", 56.0153, 92.8932));
            Cities.Add(new GPSMetadata("Austin (Texas)", 30.2672, -97.7431));

            //File.WriteAllText("cities.json", JsonConvert.SerializeObject(Cities));
            using (StreamWriter file = File.CreateText("cities.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, Cities);
            }
        }
    }
}
