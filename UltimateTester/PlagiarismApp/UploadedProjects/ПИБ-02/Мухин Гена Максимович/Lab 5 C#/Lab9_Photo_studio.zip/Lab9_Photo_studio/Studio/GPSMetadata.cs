﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;

namespace Lab9_Photo_studio
{
    internal class GPSMetadata
    {
        private const double _radians = Math.PI / 180;

        /// <summary>
        /// City Name / Image Path.
        /// </summary>
        public string ObjectName { get; set; }

        /// <summary>
        /// N - S.
        /// </summary>
        public double Longitude { get; set; }

        /// <summary>
        /// W - E.
        /// </summary>
        public double Latitude { get; set; }

        public string NearestCity { get; set; }

        // For JSON serialization.
        public GPSMetadata() { }

        // For adding a city.
        public GPSMetadata(string cityName, double latitude, double longitude)
        {
            ObjectName = cityName;
            Longitude = longitude;
            Latitude = latitude;
            NearestCity = cityName;
        }

        // For adding an image.
        public GPSMetadata(FileInfo image)
        {
            ObjectName = image.FullName;
            InitializeCoordinates(image);
        }

        void InitializeCoordinates(FileInfo image)
        {
            if (image.Extension == ".jpg")
            {
                Image img = new Bitmap(image.FullName);
                PropertyItem[] props;
                try
                {
                    props = GetGPSProperties(img); // If no gps data.
                    InitializeGPSMetadata(props);
                }
                catch (ArgumentException) // If the image has no gps data.
                {
                    InitializeUnknownLocation();
                }
            }
            else
            {
                InitializeUnknownLocation();
            }
        }

        void InitializeGPSMetadata(PropertyItem[] props)
        {
            // N W S E.
            string latitudeRef = Encoding.ASCII.GetString(new byte[1] { props[0].Value[0] });
            string longitudeRef = Encoding.ASCII.GetString(new byte[1] { props[2].Value[0] });
            // Latitude.
            uint[] latitudeValues = GetLatLongValues(props[1]);
            Latitude = ConvertDegreeAngleToDouble(latitudeValues[0] / latitudeValues[1],
                latitudeValues[2] / latitudeValues[3], latitudeValues[4] / latitudeValues[5], latitudeRef);
            // Longitude.
            uint[] longitudeValues = GetLatLongValues(props[3]);
            Longitude = ConvertDegreeAngleToDouble(longitudeValues[0] / longitudeValues[1],
                longitudeValues[2] / longitudeValues[3], longitudeValues[4] / longitudeValues[5], longitudeRef);
        }

        public static double ConvertDegreeAngleToDouble(double degrees, double minutes, double seconds, string latLongRef)
        {
            double result = ConvertDegreeAngleToDouble(degrees, minutes, seconds);
            if (latLongRef == "S" || latLongRef == "W")
            {
                result *= -1;
            }
            return result;
        }

        public static double ConvertDegreeAngleToDouble(double degrees, double minutes, double seconds)
        {
            return degrees + (minutes / 60) + (seconds / 3600);
        }

        // Gets the distance between two locations;
        // The Haversine Formula.
        public static double HaversineDistance(GPSMetadata pos1, GPSMetadata pos2)
        {
            double R = 6371; // the radius of the Earth.
            var lat = ToRadians(pos2.Latitude - pos1.Latitude);
            var lng = ToRadians(pos2.Longitude - pos1.Longitude);
            double dividedLatBy2 = lat / 2;
            double dividedLngBy2 = lng / 2;
            var sin2lat = Math.Sin(dividedLatBy2) * Math.Sin(dividedLatBy2);
            var sin2lng = Math.Sin(dividedLngBy2) * Math.Sin(dividedLngBy2);
            var cos2 = Math.Cos(ToRadians(pos1.Latitude)) * Math.Cos(ToRadians(pos2.Latitude));
            var h1 = sin2lat + cos2 * sin2lng;
            var h2 = 2 * Math.Asin(Math.Min(1, Math.Sqrt(h1)));
            return R * h2;
        }

        static double ToRadians(double value)
        {
            return value * _radians;
        }

        PropertyItem[] GetGPSProperties(Image img)
        {
            return new PropertyItem[] {
                   img.GetPropertyItem(1),
                   img.GetPropertyItem(2),
                   img.GetPropertyItem(3),
                   img.GetPropertyItem(4),
                };
        }

        uint[] GetLatLongValues(PropertyItem prop)
        {
            return new uint[]
            {
                BitConverter.ToUInt32(prop.Value, 0),
                BitConverter.ToUInt32(prop.Value, 4),
                BitConverter.ToUInt32(prop.Value, 8),
                BitConverter.ToUInt32(prop.Value, 12),
                BitConverter.ToUInt32(prop.Value, 16),
                BitConverter.ToUInt32(prop.Value, 20),
            };
        }

        void InitializeUnknownLocation()
        {
            //Latitude = 0;
            //Longitude = 0;
            // TODO: add a bool state if has gps metadata?
            NearestCity = "Unknown";
        }
    }
}