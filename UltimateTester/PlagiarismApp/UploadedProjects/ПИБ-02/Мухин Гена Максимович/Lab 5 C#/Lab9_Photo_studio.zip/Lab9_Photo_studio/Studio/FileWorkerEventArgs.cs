﻿namespace Lab9_Photo_studio
{
    public class FileWorkerEventArgs
    {
        public string From { get; set; }
        public string To { get; set; }
        public string RemovedFile { get; set; }
        public string CopyError { get; set; }
        public int FilesCount { get; set; }
    }
}
