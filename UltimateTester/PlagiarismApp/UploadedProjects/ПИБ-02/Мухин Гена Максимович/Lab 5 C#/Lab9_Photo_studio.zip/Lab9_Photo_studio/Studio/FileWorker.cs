﻿using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace Lab9_Photo_studio
{
    abstract class FileWorker
    {
        private string _copyright = "zubri-proofed";
        private string _watermark = "watercat.bmp";

        public EventHandler<FileWorkerEventArgs> OnFileCopy;
        public EventHandler<FileWorkerEventArgs> OnCopyError;

        public void Copy(string from, string to)
        {
            try
            {
                File.Copy(from, to, true);
            }
            catch (IOException copyError)
            {
                RaiseCopyErrorEvent(from, to, copyError.Message);
            }
            RaiseFileCopyEvent(from, to);
        }

        #region Raise File Copy events
        private void RaiseFileCopyEvent(string from, string to)
        {
            if (OnFileCopy != null)
            {
                FileWorkerEventArgs args = new FileWorkerEventArgs()
                {
                    From = from,
                    To = to
                };
                OnFileCopy(this, args);
            }
        }

        private void RaiseCopyErrorEvent(string from, string to, string error)
        {
            if (OnFileCopy != null)
            {
                FileWorkerEventArgs args = new FileWorkerEventArgs()
                {
                    From = from,
                    To = to,
                    CopyError = error
                };
                OnFileCopy(this, args);
            }
        }
        #endregion

        #region Textual watermark
        public void WatermarkDiagonally(string loadFromPath, string saveToPath)
        {
            try
            {
                Image img = Image.FromFile(loadFromPath);
                var verticalTranslate = -50;
                using (var brush = new SolidBrush(Color.Red))
                using (Graphics g = Graphics.FromImage(img))
                {
                    Font font = null;
                    SizeF text = new SizeF();
                    InitializeFont(g, img, ref font, ref text);
                    double hypotenuse = Math.Sqrt(img.Width * img.Width + img.Height * img.Height);
                    int rowCount = (int)(hypotenuse / font.Height);
                    int colCount = (int)Math.Ceiling(hypotenuse / text.Width);

                    for (int i = 0; i < rowCount; i++)
                    {
                        for (int j = -1; j < colCount; j++)
                        {
                            g.TranslateTransform((int)(j * text.Width- i*font.Size), verticalTranslate);
                            g.RotateTransform(-45);
                            g.TranslateTransform((int)(j * text.Height), verticalTranslate);
                            g.DrawString(_copyright, font, brush, new PointF(-img.Width * 0.2f, 0));
                            g.ResetTransform();
                        }
                        verticalTranslate += (int)(1.5 * font.Height);
                        g.ResetTransform();
                    }
                    g.Save();
                }
                img.Save(saveToPath, ImageFormat.Jpeg);
            }
            catch { }
        }

        public void Watermark(string loadFromPath, string saveToPath)
        {
            Image img = Image.FromFile(loadFromPath);
            using (var frontBrush = new SolidBrush(Color.FromArgb(90, 255, 255, 255)))
            using (var backBrush = new SolidBrush(Color.FromArgb(90, 0, 0, 0)))
            using (Graphics g = Graphics.FromImage(img))
            {
                Font font = null;
                SizeF text = new SizeF();
                InitializeFont(g, img, ref font, ref text);
                int rowCount = (int)Math.Ceiling(img.Height / text.Height / 2);
                int colCount = (int)Math.Ceiling(img.Width / text.Width);

                float halfTextHeight = text.Height / 2;
                double percent = 100.0 / (rowCount + 1) / 100.0;
                int yPixelsFromBottom = (int)(img.Height * percent);
                float yFromBottom = (img.Height - yPixelsFromBottom) - halfTextHeight;
                int oddRowOffset = (int)text.Width / 3;

                for (int i = 0; i < rowCount; i++)
                {
                    for (int j = 0; j < colCount + 1; j++)
                    {
                        yPixelsFromBottom = (int)(img.Height * (percent + (percent * i)));
                        yFromBottom = img.Height - yPixelsFromBottom - halfTextHeight;
                        float xPos = (text.Width * j) - text.Width;
                        if (i % 2 == 0)
                        {
                            g.DrawString(_copyright, font, backBrush, new PointF(xPos + 2, yFromBottom + 2));
                            g.DrawString(_copyright, font, frontBrush, new PointF(xPos, yFromBottom));
                        }
                        else if (i != rowCount)
                        {
                            xPos += oddRowOffset;
                            g.DrawString(_copyright, font, backBrush, new PointF(xPos + 2, yFromBottom + 2));
                            g.DrawString(_copyright, font, frontBrush, new PointF(xPos, yFromBottom));
                        }
                    }
                }
            }
            img.Save(saveToPath, ImageFormat.Jpeg);
        }

        // Determine which font size to use.
        void InitializeFont(Graphics grPhoto, Image img, ref Font crFont, ref SizeF crSize)
        {
            int fontSize = 141;
            for (int i = 0; i < 70; i++) // Step: 2 sizes
            {
                crFont = new Font("cambria", fontSize - (2 * i), FontStyle.Bold);
                crSize = grPhoto.MeasureString(_copyright, crFont);
                if ((ushort)crSize.Width < img.Width && (ushort)crSize.Height < img.Height)
                    break;
            }
        }
        #endregion

        #region Image watermark methods
        // Opacity depends on 0.7f value ([3][3]).
        float[][] InitializeOpacity()
        {
            float[][] arr = { new float[] {1.0f,  0.0f,  0.0f,  0.0f, 0.0f},
                              new float[] {0.0f,  1.0f,  0.0f,  0.0f, 0.0f},
                              new float[] {0.0f,  0.0f,  1.0f,  0.0f, 0.0f},
                              new float[] {0.0f,  0.0f,  0.0f,  0.7f, 0.0f},
                              new float[] {0.0f,  0.0f,  0.0f,  0.0f, 1.0f}};
            return arr;
        }
        void InitializeColorMap(ColorMap colorMap)
        {
            // The Colour to transperentize with 0 0 0 0.
            colorMap.OldColor = Color.FromArgb(255, 255, 255, 255);
            colorMap.NewColor = Color.FromArgb(0, 0, 0, 0);
        }
        #endregion
    }
}
