﻿using System;
using System.Text;

namespace Lab9_Photo_studio
{
    internal class Date
    {
        private StringBuilder _sb;
        private DateTime _date;

        public int Year => _date.Year;
        public int Month => _date.Month;
        public int Day => _date.Day;

        public int Week { get; set; }


        public Date(DateTime date)
        {
            _date = date;
            Week = GetWeekNumberOfMonth(date);
        }

        static int GetWeekNumberOfMonth(DateTime date)
        {
            date = date.Date;
            DateTime firstMonthDay = new DateTime(date.Year, date.Month, 1);
            DateTime firstMonthMonday = firstMonthDay.AddDays((DayOfWeek.Monday + 7 - firstMonthDay.DayOfWeek) % 7);
            if (firstMonthMonday > date)
            {
                firstMonthDay = firstMonthDay.AddMonths(-1);
                firstMonthMonday = firstMonthDay.AddDays((DayOfWeek.Monday + 7 - firstMonthDay.DayOfWeek) % 7);
            }
            return (date - firstMonthMonday).Days / 7 + 1;
        }

        public string GetDay()
        {
            _sb = new StringBuilder();
            _sb.Append(Year);
            _sb.Append('-');
            _sb.Append(Month);
            _sb.Append('-');
            _sb.Append(Day);
            return _sb.ToString();
        }

        public string GetWeek()
        {
            _sb = new StringBuilder();
            _sb.Append(Year);
            _sb.Append("-");
            _sb.Append(Month);
            _sb.Append(" week-");
            _sb.Append(Week);
            return _sb.ToString();
        }

        public string GetMonth()
        {
            _sb = new StringBuilder();
            _sb.Append(Year);
            _sb.Append("-");
            _sb.Append(Month);
            return _sb.ToString();
        }
    }
}