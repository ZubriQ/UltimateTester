﻿namespace Lab9_Photo_studio
{
    internal enum SortOption
    {
        Day = 1,
        Week = 2,
        Month = 3,
    }
}