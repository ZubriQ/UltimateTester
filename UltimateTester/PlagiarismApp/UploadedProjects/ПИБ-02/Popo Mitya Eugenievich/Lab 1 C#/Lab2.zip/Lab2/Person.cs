﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Person
    {
        private string _name { get; set; }

        private string _secondName { get; set; }

        private DateTime _birthDate { get; set; }

        public Person(string name, string secondName, DateTime birthDate)
        {
            _name = name;
            _secondName = secondName;
            _birthDate = birthDate;
        }

        public Person()
        {
            _name = "No name";
            _secondName = "No second name";
            _birthDate = DateTime.MinValue;
        }

        public string Name { get { return _name; } set { _name = value; } }

        public string SecondName { get { return _secondName; } set { _secondName = value; } }

        public DateTime BirthDate { get { return _birthDate; } set { _birthDate = value; } }

        public int BirthYear
        {
            get
            {
                return _birthDate.Year;
            }
            set
            {
                _birthDate = new DateTime(value, _birthDate.Month, _birthDate.Day);
            }
        }

        // Without a String Builder o.o
        public string ToFullString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("First name: ");
            sb.Append(_name);
            sb.Append(" Second name: ");
            sb.Append(_secondName);
            sb.Append(" Birth date: ");
            sb.Append(_birthDate.ToString());
            return sb.ToString();
        }

        public string ToShortString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("First name: ");
            sb.Append(_name);
            sb.Append(" Second name: ");
            sb.Append(_secondName);
            return sb.ToString();
        }
    }
}
