﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    enum TimeFrame
    {
        Year = 1,
        TwoYears = 2,
        Long = 3
    }
}
