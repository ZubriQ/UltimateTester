﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            ResearchTeam team = new ResearchTeam();
            Console.WriteLine(team.ToShortString() + "\n");

            ResearchTeam team2 = new ResearchTeam(
                "Australische seltene Krabben", "Weltschutzorganisation", 1, TimeFrame.TwoYears);
            Console.WriteLine(team2.ToString() + "\n");

            // The current latest date is 'DateTime.Now';
            // therefore, should output Raue Felsenkrabbe paper.
            Paper[] papers = { new Paper("Lila gesprenkelte Strandkrabbe", new Person(), 
                                         new DateTime(2007, DateTimeKind.Local)),
                               new Paper("Raue Felsenkrabbe", new Person(), DateTime.Now),
                               new Paper("Sandkrabbe", new Person(), new DateTime(2015, 4, 20, 11, 30, 43)),
                               new Paper("Kleine Strandkrabbe", new Person(), new DateTime(2010, 11, 27)) };
            team2.AddPapers(papers);
            Console.WriteLine("\tThe latest publication:");
            Console.WriteLine(team2.LastPublication.ToFullString());
            Console.Write("\n\n");



            // =ADDITIONAL TASK=
            // Create 3 different arrays.
            // The type of the arrays depends on the type of work.
            while (true)
            {
                // Greetings.
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine();
                Console.WriteLine("Please, enter Row and Column number.");
                Console.WriteLine("Use ',' or ';' as a separetor.");
                Console.WriteLine("For example: '500; 2000' (without the apostrophes)");
                Console.ResetColor();

                // Receive and process data.
                Console.Write("Enter: ");
                string[] info = Console.ReadLine().Split(',', ';');

                int nrow = 0;
                int ncolumn = 0;
                bool ok = true;

                if (info.Length == 2)
                {
                    if (ok)
                        ok = Int32.TryParse(info[0], out nrow);
                    if (ok)
                        ok = Int32.TryParse(info[1], out ncolumn);
                }
                else ok = false;

                if (ok)
                {
                    try
                    {
                        // If entered data is OK,
                        // declare the arrays with the same element count,
                        // initialize them and assign new objects.
                        Console.WriteLine("[System]: Declaring arrays...");
                        
                        Paper[] simpleArray = new Paper[nrow * ncolumn];
                        Paper[,] twoDimensionalArray = new Paper[nrow, ncolumn];
                        Paper[][] jaggedArray = new Paper[nrow][];
                        for (int i = 0; i < nrow; i++)
                            jaggedArray[i] = new Paper[ncolumn];

                        // Initialize the arrays.
                        Console.WriteLine("[System]: Initializing arrays...");
                        for (int i = 0; i < simpleArray.Length; i++)
                            simpleArray[i] = new Paper();

                        for (int i = 0; i < nrow; i++)
                            for (int j = 0; j < ncolumn; j++)
                                twoDimensionalArray[i, j] = new Paper();

                        for (int i = 0; i < jaggedArray.Length; i++)
                            for (int j = 0; j < jaggedArray[i].Length; j++)
                                jaggedArray[i][j] = new Paper();

                        // Comparing time execution of assigning Person to an item of an array:
                        Console.WriteLine("\tFirst execution:");
                        CompareTime(simpleArray, twoDimensionalArray, jaggedArray);
                        Console.WriteLine("\tSecond execution:");
                        CompareTime(simpleArray, twoDimensionalArray, jaggedArray);
                    }
                    catch (Exception)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("[Error]: Entered Row and Column numbers are too large; try smaller numbers.");
                        Console.ResetColor();
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\nIncorrect input.\nTry to type something similar: '400, 1000'");
                    Console.ResetColor();
                } 
            }

            //Console.ReadLine();
        }

        static void CompareTime(Paper[] oneDimArr, Paper[,] twoDimArr, Paper[][] jaggedArr)
        {
            Console.WriteLine("[System]: Changing data in arrays...");
            long duration;
            Stopwatch sw = new Stopwatch();

            sw.Start();
            for (int i = 0; i < oneDimArr.Length; i++)
                oneDimArr[i].Count++;
            duration = sw.ElapsedMilliseconds;
            Console.WriteLine($"[1-Dimensional Array]:\tThe process took {duration} milliseconds.");

            sw.Restart();
            for (int i = 0; i < twoDimArr.GetLength(0); i++)
                for (int j = 0; j < twoDimArr.GetLength(1); j++)
                    twoDimArr[i, j].Count++;
            duration = sw.ElapsedMilliseconds;
            Console.WriteLine($"[2-Dimensional Array]:\tThe process took {duration} milliseconds.");

            sw.Restart();
            for (int i = 0; i < jaggedArr.Length; i++)
                for (int j = 0; j < jaggedArr[i].Length; j++)
                    jaggedArr[i][j].Count++;
            duration = sw.ElapsedMilliseconds;
            Console.WriteLine($"[Jagged Array]:\t\tThe process took {duration} milliseconds.");
        }
    }
}
