﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class ResearchTeam
    {
        private string _researchTopic { get; set; }

        private string _organizationName { get; set; }

        private int _registrationNumber { get; set; }

        /// <summary>
        /// Research duration.
        /// </summary>
        private TimeFrame _timeFrame { get; set; }

        private Paper[] _publications { get; set; }

        public ResearchTeam(string topicName, string orgName, int regNum, TimeFrame timeFrame)
        {
            _researchTopic = topicName;
            _organizationName = orgName;
            _registrationNumber = regNum;
            _timeFrame = timeFrame;
            // Nothing is said about the initialization of the papers.
            _publications = new Paper[0];
        }

        public ResearchTeam()
        {
            _researchTopic = "No research topic name";
            _organizationName = "No organization name";
            _registrationNumber = -1;
            _timeFrame = TimeFrame.Long;
            // Nothing is said about the initialization of the papers.
            _publications = new Paper[0];
        }

        public string ResearchTopic { get { return _researchTopic; } set { _researchTopic = value; } }

        public string OrganizationName { get { return _organizationName; } set { _organizationName = value; } }

        public int RegistrationNumber { get { return _registrationNumber; } set { _registrationNumber = value; } }

        public TimeFrame TimeFrame { get { return _timeFrame; } set { _timeFrame = value; } }

        public Paper[] Publications { get { return _publications; } set { _publications = value; } }

        public Paper LastPublication
        {
            get
            {
                if (_publications.Count() == 0)
                    return null;
                else return GetLatestPaper();
            }
        }

        private Paper GetLatestPaper()
        {
            Paper result = _publications[0];
            // Not sorted array O(n)
            for (int i = 0; i < _publications.Count(p => p != null); i++)
            {
                if (result.PublicationDate < _publications[i].PublicationDate)
                    result = _publications[i];
            }
            return result;
        }

        public void AddPapers(params Paper[] papers)
        {
            Paper[] result = null;

            if (_publications == null)
                _publications = new Paper[papers.Length];
            else
                result = new Paper[papers.Length + _publications.Length];

            // Concatenation.
            int index = 0;

            for (int i = 0; i < _publications.Length; i++)
                result[index++] = _publications[i];

            for (int j = 0; j < papers.Length; j++)
                result[index++] = papers[j];

            _publications = result;
        }

        private string GetFormattedPapers()
        {
            string result = "";
            for (int i = 0; i < _publications.Length; i++)
            {
                result += _publications[i].ToFullString() + "\n";
            }
            return result;
        }

        public string ToFullString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("\tResearch topic name:\t");
            sb.Append(_researchTopic);
            sb.Append("\n\tOrganization name:\t");
            sb.Append(_organizationName);
            sb.Append("\n\tRegistration number:\t");
            sb.Append(_registrationNumber);
            sb.Append("\n\tTime frame:\t\t");
            sb.Append(_timeFrame);
            sb.Append("\n\tPubclications:\n");
            sb.Append(GetFormattedPapers());
            return sb.ToString();
        }

        public string ToShortString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("\tResearch topic name:\t");
            sb.Append(_researchTopic);
            sb.Append("\n\tOrganization name:\t");
            sb.Append(_organizationName);
            sb.Append("\n\tRegistration number:\t");
            sb.Append(_registrationNumber);
            sb.Append("\n\tTime frame:\t\t");
            sb.Append(_timeFrame);
            return sb.ToString();
        }
    }
}
