﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Paper
    {
        public string Name { get; set; }

        public Person Author { get; set; }

        // Testing field.
        public int Count { get; set; }

        public DateTime PublicationDate { get; set; }

        public Paper(string name, Person author, DateTime publicationDate)
        {
            Name = name;
            Author = author;
            PublicationDate = publicationDate;
        }

        public Paper()
        {
            Name = "No publication name";
            Author = new Person();
            PublicationDate = DateTime.Now;
        }

        public string ToFullString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Publication name:\t");
            sb.Append(Name);
            sb.Append("\nAuthor:\t\t\t");
            sb.Append(Author.ToFullString());
            sb.Append("\nPublication date:\t");
            sb.Append(PublicationDate.ToString());
            return sb.ToString();
        }
    }
}
