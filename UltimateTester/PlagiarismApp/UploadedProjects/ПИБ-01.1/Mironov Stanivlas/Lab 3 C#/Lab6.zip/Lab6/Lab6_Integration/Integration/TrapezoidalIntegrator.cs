﻿using System;
using System.Threading;

namespace Lab6_Integration.Integration
{
    internal class TrapezoidalIntegrator : Integrator
    {
        public TrapezoidalIntegrator(Equation equation) : base(equation) { }
        public TrapezoidalIntegrator() { }

        public override double Integrate(double x1, double x2, int n)
        {
            if (x1 >= x2)
            {
                throw new ArgumentException("Правая граница интегирования должны быть больше левой!");
            }
            RaiseStartEvent();
            double h = (x2 - x1) / n;
            double sum = 0;
            double f, x;
            for (int i = 0; i <= n; i++)
            {
                Thread.Sleep(1);
                if (i == 0 || i == n)
                {
                    x = x1 + i * h;
                    f = IntegratingHandler(x);
                    sum = sum + f * (h / 2);
                }
                else
                {
                    x = x1 + i * h;
                    f = IntegratingHandler(x);
                    sum = sum + f * h;
                }
                RaiseStepEvent(x, f, sum);
            }
            RaiseFinishEvent(sum);
            return sum;
        }

        public override string ToString()
        {
            return "Trapezoidal rule";
        }
    }
}
