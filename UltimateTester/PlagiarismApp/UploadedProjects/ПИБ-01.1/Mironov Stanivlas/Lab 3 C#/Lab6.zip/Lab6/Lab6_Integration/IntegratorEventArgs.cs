﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Integration
{
    public class IntegratorEventArgs
    {
        public double X { get; set; }
        public double F { get; set; }
        public double Integr { get; set; }
    }
}
