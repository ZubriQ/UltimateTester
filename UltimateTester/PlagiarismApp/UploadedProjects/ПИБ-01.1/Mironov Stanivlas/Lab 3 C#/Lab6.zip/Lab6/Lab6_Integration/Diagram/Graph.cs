﻿using System.Windows.Media;

namespace Lab6_Integration.Diagram
{
    public class Graph
    {
        public int Diameter { get; private set; }
        public Brush Colour { get; private set; }

        public Graph() { }

        public Graph(int diameter, Brush colour)
        {
            Diameter = diameter;
            Colour = colour;
        }
    }
}
