﻿using Lab6_Integration.Diagram;
using Lab6_Integration.Integration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab6_Integration
{
    public partial class MainWindow : Window
    {
        public int ImageWidth;
        public int ImageHeight;

        public Chart Chart { get; set; }
        public Equation Function { get; set; }
        public Integrator Integrator { get; set; }

        /// <summary>
        /// Either the number of splits or the number of points.
        /// </summary>
        public int N { get; set; }

        // Needed to draw points for Monte Carlo.
        private readonly static Random _random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            drawingDockPanel.Background = new SolidColorBrush(Color.FromRgb(30, 30, 30));
            drawingCanvas.Background = new SolidColorBrush(Color.FromRgb(42, 42, 42));
        }

        internal void DrawFunction(double x0, double x1)
        {
            double maxY = Chart.GraphCenter.Y;
            double minY = Chart.GraphCenter.Y;
            List<Point> coordinates = new List<Point>();
            for (double x = x0; x < x1; x += 0.02)
            {
                double y = -Integrator.IntegratingHandler(x);
                coordinates.Add(new Point(x * Chart.Ratio.X + Chart.GraphCenter.X,
                                          y * Chart.Ratio.Y + Chart.GraphCenter.Y));
                if (maxY < y * Chart.Ratio.Y + Chart.GraphCenter.Y)
                    maxY = y * Chart.Ratio.Y + Chart.GraphCenter.Y;
                if (minY > y * Chart.Ratio.Y + Chart.GraphCenter.Y)
                    minY = y * Chart.Ratio.Y + Chart.GraphCenter.Y;
            }
            DrawPolyline(coordinates);
            ShowIntegrationResult(x0, x1, maxY, minY);
        }

        private void DrawPolyline(List<Point> points)
        {

            PointCollection pc = new PointCollection(points);
            Polyline polyline = new Polyline()
            {
                Points = pc,
                Stroke = Chart.Graph.Colour,
                StrokeThickness = Chart.Graph.Diameter,
                StrokeLineJoin = PenLineJoin.Round
            };
            Canvas.SetTop(polyline, 0);
            Canvas.SetLeft(polyline, 0);
            drawingCanvas.Children.Add(polyline);
        }

        private void ShowIntegrationResult(double x0, double x1, double maxY, double minY)
        {
            Math.Round(Integrator.Integrate(x0, x1, N), 4);
            if (Integrator is MonteCarloIntegrator)
                DrawMonteCarlo(x0, x1, maxY, minY);
        }

        // If you want to draw points in Monte Carlo.
        private void DrawMonteCarlo(double x0, double x1, double maxY, double minY)
        {
            Brush brushPositive = new SolidColorBrush(Colors.LightGreen);
            Brush brushNegative = new SolidColorBrush(Colors.Crimson);
            Brush brushLowOutside = new SolidColorBrush(Colors.Black);
            Brush brushHighOutside = new SolidColorBrush(Colors.Ivory);
            int pointDiamter = 2;

            for (int i = 0; i < N; i++)
            {
                double randomX = RandomNumberBetween(x0, x1);
                double chartX = randomX * Chart.Ratio.X + Chart.GraphCenter.X;
                double randomY = RandomNumberBetween(minY, maxY);
                double fy = -Integrator.IntegratingHandler(randomX) * Chart.Ratio.Y + Chart.GraphCenter.Y;

                if (randomY > Chart.GraphCenter.Y)
                {
                    if (fy > randomY)
                    {
                        DrawCircle(chartX, randomY, brushNegative, pointDiamter);
                    }
                    else DrawCircle(chartX, randomY, brushLowOutside, pointDiamter);
                }
                else
                {
                    if (fy < randomY)
                    {
                        DrawCircle(chartX, randomY, brushPositive, pointDiamter);
                    }
                    else DrawCircle(chartX, randomY, brushHighOutside, pointDiamter);
                }
            }
        }

        private double RandomNumberBetween(double minValue, double maxValue)
        {
            var next = _random.NextDouble();
            return minValue + (next * (maxValue - minValue));
        }


        #region With Equation class
        //internal void DrawFunction(double x0, double x1)
        //{
        //    double maxY = Chart.GraphCenter.Y;
        //    double minY = Chart.GraphCenter.Y;
        //    for (double x = x0; x < x1; x += 0.1)
        //    {
        //        double y = -Integrator.IntegratingHandler(x);
        //        DrawCircle(x * Chart.Ratio.X + Chart.GraphCenter.X,
        //                   y * Chart.Ratio.Y + Chart.GraphCenter.Y,
        //                   Chart.Graph.Colour, Chart.Graph.Diameter);
        //        if (maxY < y * Chart.Ratio.Y + Chart.GraphCenter.Y)
        //            maxY = y * Chart.Ratio.Y + Chart.GraphCenter.Y;
        //        if (minY > y * Chart.Ratio.Y + Chart.GraphCenter.Y)
        //            minY = y * Chart.Ratio.Y + Chart.GraphCenter.Y;
        //    }
        //    //ShowIntegrationResult(x0, x1, maxY, minY, eq);
        //    ShowIntegrationResult(x0, x1, maxY, minY);
        //}

        // If you want to draw points in Monte Carlo.
        // Draws point by point.
        //internal void DrawFunction(double x0, double x1, Equation eq)
        //{
        //    double maxY = Chart.GraphCenter.Y;
        //    double minY = Chart.GraphCenter.Y;
        //    for (double x = x0; x < x1; x += 0.01)
        //    {
        //        double y = -eq.GetValue(x);
        //        DrawCircle(x * Chart.Ratio.X + Chart.GraphCenter.X,
        //                   y * Chart.Ratio.Y + Chart.GraphCenter.Y,
        //                   Chart.Graph.Colour, Chart.Graph.Diameter);

        //        if (maxY < y * Chart.Ratio.Y + Chart.GraphCenter.Y)
        //            maxY = y * Chart.Ratio.Y + Chart.GraphCenter.Y;
        //        if (minY > y * Chart.Ratio.Y + Chart.GraphCenter.Y)
        //            minY = y * Chart.Ratio.Y + Chart.GraphCenter.Y;
        //    }
        //    ShowIntegrationResult(x0, x1, maxY, minY, eq);
        //}

        //private void DrawMonteCarlo(double x0, double x1, double maxY, double minY, Equation eq)
        //{
        //    for (int i = 0; i < N; i++)
        //    {
        //        double randomX = Random.NextDouble() + Random.Next((int)x0, (int)x1);
        //        double chartX = randomX * Chart.Ratio.X + Chart.GraphCenter.X;
        //        double randomY = Random.NextDouble() + Random.Next((int)minY, (int)maxY);
        //        Brush brushPositive = new SolidColorBrush(Colors.LightGreen);
        //        Brush brushNegative = new SolidColorBrush(Colors.Crimson);
        //        Brush brushLowOutside = new SolidColorBrush(Colors.Black);
        //        Brush brushHighOutside = new SolidColorBrush(Colors.Ivory);

        //        if (randomY > Chart.GraphCenter.Y)
        //        {
        //            double fy = -eq.GetValue(randomX) * Chart.Ratio.Y + Chart.GraphCenter.Y;
        //            if (fy > randomY)
        //            {
        //                DrawCircle(chartX, randomY, brushNegative, 2);
        //            }
        //            else DrawCircle(chartX, randomY, brushLowOutside, 2);
        //        }
        //        else
        //        {
        //            double fy = -eq.GetValue(randomX) * Chart.Ratio.Y + Chart.GraphCenter.Y;
        //            if (fy < randomY)
        //            {
        //                DrawCircle(chartX, randomY, brushPositive, 2);
        //            }
        //            else DrawCircle(chartX, randomY, brushHighOutside, 2);
        //        }
        //    }
        //}

        //private void ShowIntegrationResult(double x0, double x1, double maxY, double minY, Equation eq)
        //{
        //    lblIntegrationMethod.Content = Integrator.ToString();
        //    if (Integrator is MonteCarloIntegrator)
        //        DrawMonteCarlo(x0, x1, maxY, minY, eq);
        //    lblVolume.Content = Math.Round(Integrator.Integrate(x0, x1, N), 4);
        //}
        #endregion


        private void DrawCircle(double xc, double yc, Brush brush, int diameter)
        {
            Ellipse ellipse = new Ellipse();
            ellipse.Fill = brush;
            ellipse.Width = diameter;
            ellipse.Height = diameter;
            Canvas.SetTop(ellipse, yc - (diameter / 2));
            Canvas.SetLeft(ellipse, xc - (diameter / 2));
            drawingCanvas.Children.Add(ellipse);
        }


        //private void DrawPoint(double xc, double yc, Brush brush)
        //{
        //    Rectangle point = new Rectangle();
        //    point.Fill = brush;
        //    point.Width = 1;
        //    point.Height = 1;
        //    Canvas.SetTop(point, yc);
        //    Canvas.SetLeft(point, xc);
        //    drawingCanvas.Children.Add(point);
        //}


        #region Draw axes
        // TODO: fix ticks range
        internal void DrawAxes()
        {
            SetXAxis();
            SetYAxis();
        }

        private void SetXAxis()
        {
            Line axis = new Line(); // Draw X axis.
            axis.X1 = 0;
            axis.Y1 = Chart.GraphCenter.Y;
            axis.X2 = ImageWidth;
            axis.Y2 = Chart.GraphCenter.Y;
            axis.Stroke = Chart.Axis.Colour;
            axis.StrokeThickness = 1;
            drawingCanvas.Children.Add(axis);
            // Draw ticks for X axis.
            for (double i = 0; i <= ImageWidth; i += Chart.Axis.TicksStepValue * Chart.Ratio.X)
            {
                Line tick = new Line();
                tick.X1 = i;
                tick.Y1 = Chart.GraphCenter.Y;
                tick.X2 = i;
                tick.Y2 = Chart.GraphCenter.Y - Chart.Axis.TicksLineLength;
                tick.Stroke = Chart.Axis.Colour;
                tick.StrokeThickness = 1;
                drawingCanvas.Children.Add(tick);
            }
        }

        private void SetYAxis()
        {
            Line axis = new Line(); // Draw Y axis.
            axis.X1 = Chart.GraphCenter.X;
            axis.Y1 = 0;
            axis.X2 = Chart.GraphCenter.X;
            axis.Y2 = ImageHeight;
            axis.Stroke = Chart.Axis.Colour;
            axis.StrokeThickness = 1;
            drawingCanvas.Children.Add(axis);
            // Draw ticks for Y axis.
            for (double i = 0; i <= ImageHeight; i += Chart.Axis.TicksStepValue * Chart.Ratio.Y)
            {
                Line tick = new Line();
                tick.X1 = Chart.GraphCenter.X;
                tick.Y1 = i;
                tick.X2 = Chart.GraphCenter.X + Chart.Axis.TicksLineLength;
                tick.Y2 = i;
                tick.Stroke = Chart.Axis.Colour;
                tick.StrokeThickness = 1;
                drawingCanvas.Children.Add(tick);
            }
        }
        #endregion


        #region Menu
        private void miCreate_Click(object sender, RoutedEventArgs e)
        {
            CreateChartWindow w = new CreateChartWindow();
            w.ShowDialog();
        }
        #endregion
    }
}
