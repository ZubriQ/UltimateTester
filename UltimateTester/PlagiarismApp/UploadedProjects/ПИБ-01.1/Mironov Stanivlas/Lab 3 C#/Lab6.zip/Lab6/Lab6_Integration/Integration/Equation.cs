﻿namespace Lab6_Integration.Integration
{
    public abstract class Equation
    {
        public string Name { get; set; }
        public abstract double GetValue(double value);
    }
}
