﻿using System;
using System.Threading;

namespace Lab6_Integration.Integration
{
    internal class RectangularIntegrator : Integrator
    {
        public RectangularIntegrator(Equation equation) : base(equation) { }
        public RectangularIntegrator() 
        {
            
        }

        public override double Integrate(double x1, double x2, int n)
        {
            if (x1 >= x2)
            {
                throw new ArgumentException("Правая граница интегирования должны быть больше левой!");
            }
            RaiseStartEvent();
            /* для интегирования разобъем исходный отрезок на 100 точек. 
             * Считаем значение функции в точке, умножаем на ширину интервала.
             * Площадь полученного прямоугольника приблизительно равна значению интеграла на этом отрезке
             * суммируем значения площадей, получаем значение интеграла на отрезке [X1;X2]*/
            //определяем ширину интервала:
            double h = (x2 - x1) / n;
            double sum = 0; //"накопитель" для значения интеграла
            for (int i = 0; i < n; i++)
            {
                Thread.Sleep(1);
                //sum = sum + equation.GetValue(x1 + i * h) * h;
                double x = x1 + i * h;
                double f = IntegratingHandler(x);
                sum = sum + f * h;
                RaiseStepEvent(x, f, sum);
            }
            RaiseFinishEvent(sum);
            return sum;
        }

        public override string ToString()
        {
            return "Rectangle rule";
        }
    }
}
