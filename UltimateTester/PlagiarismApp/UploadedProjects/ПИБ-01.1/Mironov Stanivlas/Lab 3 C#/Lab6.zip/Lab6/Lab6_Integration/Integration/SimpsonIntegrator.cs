﻿using System;
using System.Threading;

namespace Lab6_Integration.Integration
{
    public class SimpsonIntegrator : Integrator
    {
        public SimpsonIntegrator(Equation equation) : base(equation) { }
        public SimpsonIntegrator() { }

        public override double Integrate(double x1, double x2, int n)
        {
            if (x1 >= x2)
            {
                throw new ArgumentException("Правая граница интегирования должны быть больше левой!");
            }
            if (n < 0)
            {
                throw new ArgumentException("N должно быть положительным!");
            }
            if (n % 2 != 0)
            {
                throw new ArgumentException("N должно быть четным!");
            }
            RaiseStartEvent();
            double h = (x2 - x1) / n;
            double sum = 0;
            double x = x1;
            double f = IntegratingHandler(x1); // function value
            sum += f * (h / 3);
            RaiseStepEvent(x1, f, sum);
            for (int i = 1; i < n; i++)
            {
                Thread.Sleep(1);
                if (i % 2 == 1)
                {
                    x = x1 + i * h;
                    f = 4 * IntegratingHandler(x);
                    sum += f * (h / 3);
                }
                else
                {
                    x = x1 + i * h;
                    f = 2 * IntegratingHandler(x);
                    sum += f * (h / 3);
                }
                RaiseStepEvent(x, f, sum);
            }
            f = IntegratingHandler(x2);
            sum += f * (h / 3);
            RaiseStepEvent(x2, f, sum);
            RaiseFinishEvent(sum);
            return sum;
        }

        public override string ToString()
        {
            return "Simpson's rule";
        }
    }
}
