﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Integration
{
    public static class FunctionProvider
    {
        public static double A { get; set; }
        public static double B { get; set; }
        public static double C { get; set; }

        public static double QuadricEquation(double x)
        {
            return A * x * x + B * x + C;
        }

        public static double CosEquation(double x)
        {
            return x * x * Math.Cos(x - A) / B;
        }

        public static double AbsSinEquation(double x)
        {
            return A * x * Math.Abs(Math.Sin(x));
        }
    }
}
