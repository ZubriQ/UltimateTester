﻿using System;

namespace Lab6_Integration.Integration
{
    public class AbsSinEquation : Equation
    {
        private readonly double a;

        public AbsSinEquation() { }

        public AbsSinEquation(double a)
        {
            this.a = a;
        }
        public override double GetValue(double x)
        {
            return a * x * Math.Abs(Math.Sin(x));
        }

        public override string ToString()
        {
            return "Abs Sin equation";
        }
    }
}
