﻿using System;

namespace Lab6_Integration.Integration
{
    public class CosEquation : Equation
    {
        private readonly double a;
        private readonly double b;

        public CosEquation() { }

        public CosEquation(double a, double b)
        {
            this.a = a;
            this.b = b;
        }
        public override double GetValue(double x)
        {
            return x * x * Math.Cos(x - a) / b;
        }

        public override string ToString()
        {
            return "Cos equation";
        }
    }
}
