﻿namespace Lab6_Integration.Diagram
{
    public class Chart
    {
        public Coordinate GraphCenter { get; private set; }

        public Coordinate Ratio { get; private set; }

        public Axis Axis { get; private set; }

        public Graph Graph { get; private set; }

        public Chart(Coordinate graphCenter, Coordinate ratio, Axis axis, Graph graph)
        {
            GraphCenter = graphCenter;
            Ratio = ratio;
            Axis = axis;
            Graph = graph;
        }
    }
}
