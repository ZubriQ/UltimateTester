﻿using System.Windows.Media;

namespace Lab6_Integration.Diagram
{
    public class Axis
    {
        public int TicksLineLength { get; private set; }
        public double TicksStepValue { get; private set; }
        public Brush Colour { get; private set; }

        public Axis() { }

        public Axis(int ticksLineLength, double ticksStepValue, Brush colour)
        {
            TicksLineLength = ticksLineLength;
            TicksStepValue = ticksStepValue;
            Colour = colour;
        }
    }
}
