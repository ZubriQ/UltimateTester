﻿using System;
using System.Threading;

namespace Lab6_Integration.Integration
{
    internal class MonteCarloIntegrator : Integrator
    {
        public MonteCarloIntegrator(Equation equation) : base(equation) { }
        public MonteCarloIntegrator() { }

        private readonly Random _random = new Random();

        public override double Integrate(double x0, double x1, int n)
        {
            if (x0 >= x1)
            {
                throw new ArgumentException("Monte Carlo is sad! Don't make Monte Carlo sad.");
            }
            if (n > 50000)
            {
                throw new ArgumentException("Too many points for poor Monte Carlo. It'd take too much time.");
            }
            RaiseStartEvent();
            // Get min and max y values of a function.
            double maxY = 0;
            double minY = 0;
            GetYLength(x0, x1, ref maxY, ref minY);
            // Count inside points.
            int negativePoints = 0;
            int positivePoints = 0;
            for (int i = 0; i < n; i++)
            {
                Thread.Sleep(1);
                double randomX = RandomNumberBetween(x0,x1);
                double randomY = RandomNumberBetween(minY, maxY);
                double fy = IntegratingHandler(randomX);

                if (randomY < 0 && randomY >= fy) // if y is negative.
                {
                    negativePoints++; // if it lies over the function. 
                }
                else if (randomY > 0 && randomY <= fy) // else y is positive.
                { 
                    positivePoints++; // if it lies under the function.
                }
            }
            double S = (maxY - minY) * (x1 - x0);
            int K = positivePoints - negativePoints;
            double result = S * K / n;
            RaiseFinishEvent(result);
            return result; // Find and return volume.
        }

        private void GetYLength(double x0, double x1, ref double maxY, ref double minY)
        {
            for (double x = x0; x < x1; x += 1)
            {
                double y = IntegratingHandler(x);
                if (maxY < y)
                    maxY = y;
                if (minY > y)
                    minY = y;
            }
        }

        private double RandomNumberBetween(double minValue, double maxValue)
        {
            var next = _random.NextDouble();
            return minValue + (next * (maxValue - minValue));
        }

        public override string ToString()
        {
            return "Monte Carlo";
        }
    }
}
