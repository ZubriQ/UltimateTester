﻿using System;
using System.Threading;

namespace Lab6_Integration.Integration
{
    public abstract class Integrator
    {
        //public delegate void IntStepDelegate(double x, double y, double integr);
        //public delegate void IntFinishDelegate(double integr);
        //public event IntStepDelegate OnStep;
        public EventHandler<IntegratorEventArgs> OnStep;
        //public event IntFinishDelegate OnFinish;
        public EventHandler<IntegratorEventArgs> OnFinish;
        public EventHandler<IntegratorEventArgs> OnStart;

        public delegate double Integration(double value);
        public Integration IntegratingHandler;

        protected Equation equation;
        public abstract double Integrate(double x1, double x2, int n);

        public Integrator(Equation equation)
        {
            if (equation == null)
            {
                throw new ArgumentNullException();
            }
            this.equation = equation;
        }

        public Integrator() 
        {
            // We don't need equation class anymore.
            equation = null;
        }

        protected void RaiseStepEvent(double x, double y, double sum)
        {
            //OnStep?.Invoke(x, y, sum);
            if (OnStep != null)
            {
                IntegratorEventArgs e = new IntegratorEventArgs()
                {
                    X = x,
                    F = y,
                    Integr = sum
                };
                OnStep(this, e);
            }
        }

        protected void RaiseFinishEvent(double sum)
        {
            //OnFinish?.Invoke(sum);
            if (OnFinish != null)
            {
                IntegratorEventArgs e = new IntegratorEventArgs()
                {
                    Integr = sum
                };
                OnFinish(this, e);
            }
        }

        protected void RaiseStartEvent()
        {
            if (OnStart != null)
            {
                IntegratorEventArgs e = new IntegratorEventArgs();
                OnStart(this, e);
            }
        }
    }
}
