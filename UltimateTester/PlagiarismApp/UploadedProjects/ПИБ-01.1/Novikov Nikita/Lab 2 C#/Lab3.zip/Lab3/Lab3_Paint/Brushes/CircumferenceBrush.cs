﻿using System.Drawing;

namespace Lab3_Paint
{
    internal class CircumferenceBrush : Brush
    {
        private int _diameter;

        public CircumferenceBrush(Color brushColour, int size) : base(brushColour, size)
        {
            _diameter = 3 - 2 * size;
        }

        // Bresenham's algorithm
        public override void Draw(Bitmap image, int xc, int yc)
        {
            int x = 0;
            int y = Size;

            DrawPixels(image, xc, yc, x, y);
            while (x <= y)
            {
                if (_diameter <= 0)
                {
                    _diameter += (4 * x) + 6;
                }
                else
                {
                    _diameter += (4 * x) - (4 * y) + 10;
                    y--;
                }
                x++;
                DrawPixels(image, xc, yc, x, y);
            }
        }

        private void DrawPixels(Bitmap image, int xc, int yc, int x, int y)
        {
            SetPixel(x + xc, y + yc, image);
            SetPixel(x + xc, -y + yc, image);
            SetPixel(-x + xc, -y + yc, image);
            SetPixel(-x + xc, y + yc, image);
            SetPixel(y + xc, x + yc, image);
            SetPixel(y + xc, -x + yc, image);
            SetPixel(-y + xc, -x + yc, image);
            SetPixel(-y + xc, x + yc, image);
        }
    }
}
