﻿using System.Drawing;

namespace Lab3_Paint
{
    internal class Eraser : Brush
    {
        public Eraser(Color brushColour, int size) : base(brushColour, size) 
        {
            BrushColour = Color.White;
        }

        public override void Draw(Bitmap image, int x, int y)
        {
            for (int y0 = y - Size; y0 < y + Size; ++y0)
                for (int x0 = x - Size; x0 < x + Size; ++x0)
                    SetPixel(x0, y0, image);
        }
    }
}
