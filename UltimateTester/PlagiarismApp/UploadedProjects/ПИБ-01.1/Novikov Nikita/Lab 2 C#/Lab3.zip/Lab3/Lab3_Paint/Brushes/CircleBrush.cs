﻿using System;
using System.Drawing;

namespace Lab3_Paint
{
    internal class CircleBrush : Brush
    {
        public CircleBrush(Color brushColour, int size) : base(brushColour, size) { }

        public override void Draw(Bitmap image, int xc, int yc)
        {
            for (int x = xc - Size; x <= xc + Size; x++)
                for (int y = yc - Size; y <= yc + Size; y++)
                {
                    double distance = Math.Sqrt(Math.Pow(x - xc, 2) + Math.Pow(y - yc, 2));

                    if (Size >= distance)
                        SetPixel(x, y, image);
                }
        }
    }
}
