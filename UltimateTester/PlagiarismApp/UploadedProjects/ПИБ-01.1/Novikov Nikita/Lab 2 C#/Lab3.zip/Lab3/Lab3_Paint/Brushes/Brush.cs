﻿using System.Drawing;

namespace Lab3_Paint
{
    abstract class Brush
    {
        public Color BrushColour { get; set; }

        public int Size { get; set; }

        public Brush(Color brushColour, int size)
        {
            BrushColour = brushColour;
            Size = size;
        }

        public abstract void Draw(Bitmap image, int x, int y);

        protected void SetPixel(int x, int y, Bitmap image)
        {
            if (!(x < 0 || y < 0) && (x < image.Width && y < image.Height))
                image.SetPixel(x, y, BrushColour);
        }
    }
}
