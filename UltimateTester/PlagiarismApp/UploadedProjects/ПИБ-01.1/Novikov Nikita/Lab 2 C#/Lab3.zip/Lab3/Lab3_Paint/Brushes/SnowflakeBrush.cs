﻿using System.Drawing;

namespace Lab3_Paint
{
    internal class SnowflakeBrush : Brush
    {
        private int _diameter;

        public SnowflakeBrush(Color brushColour, int size) : base(brushColour, size)
        {
            _diameter = size * 2; 
        }

        public override void Draw(Bitmap image, int xc, int yc)
        {
            // Vertical line.
            int y = yc - Size;
            for (; y <= yc + Size; y++)
            {
                SetPixel(xc, y, image);
            }

            // Horizontal line.
            int x = xc - Size;
            for (; x <= xc + Size; x++)
            {
                SetPixel(x, yc, image);
            }

            // Diagonal lines.
            x = xc - Size;
            y = yc + Size;
            for (int i = 0; i < _diameter; i++)
            {
                SetPixel(x++, y--, image);
            }

            x = xc + Size;
            y = yc + Size;
            for (int i = 0; i < _diameter; i++)
            {
                SetPixel(x--, y--, image);
            }
        }
    }
}
