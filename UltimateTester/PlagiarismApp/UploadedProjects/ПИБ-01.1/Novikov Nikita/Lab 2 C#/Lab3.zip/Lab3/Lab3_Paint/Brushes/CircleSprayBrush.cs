﻿using System;
using System.Drawing;

namespace Lab3_Paint
{
    internal class CircleSprayBrush : Brush
    {
        private readonly Random _random;

        private int _diameter;

        public CircleSprayBrush(Color brushColour, int size) : base(brushColour, size)
        {
            _diameter = size * 2;
            _random = new Random();
        }

        public override void Draw(Bitmap image, int xc, int yc)
        {
            int xMin = xc - Size;
            int xMax = xc + Size;
            int yMin = yc - Size;
            int yMax = yc + Size;
            int iterations = (int)(_diameter / Math.E);

            for (int i = 0; i < iterations; i++)
            {
                int x = _random.Next(xMin, xMax);
                int y = _random.Next(yMin, yMax);

                double distance = Math.Sqrt(Math.Pow(x - xc, 2) + Math.Pow(y - yc, 2));

                if (Size >= distance)
                    SetPixel(x, y, image);
            }
        }
    }
}
