﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_Paint
{
    public partial class CreateImageForm : Form
    {
        bool _canceled = true;
        public bool Canceled
        {
            get
            {
                return _canceled;
            }
        }

        public string FileName
        {
            get
            {
                return txtFileName.Text;
            }
        }

        public int W
        { 
            get
            {
                string text = txtWidth.Text;
                //int value = Convert.ToInt32(text);
                int value;
                Int32.TryParse(text, out value);
                return value;
            }
        }

        public int H
        {
            get
            {
                string text = txtHeight.Text;
                //int value = Convert.ToInt32(text);
                int value;
                Int32.TryParse(text, out value);
                return value;
            }
        }

        FlowLayoutPanel _mainPanel = new FlowLayoutPanel()
        {
            Anchor = AnchorStyles.None,
        };

        TableLayoutPanel _tableLayoutPanel = new TableLayoutPanel()
        {
            RowCount = 5,
            ColumnCount = 2,
        };

        public CreateImageForm()
        {
            InitializeComponent();
            InitializeControls();
        }

        private void InitializeControls()
        {
            _mainPanel.Controls.Add(_tableLayoutPanel);

            CreateLayoutMatrixStyles();
            SetLabelStyles();
            AddControls();

            Controls.Add(_mainPanel);
        }

        private void CreateLayoutMatrixStyles()
        {
            for (int i = 0; i < 4; i++)
            {
                _tableLayoutPanel.RowStyles.Add(new RowStyle());
                _tableLayoutPanel.RowStyles[i].SizeType = SizeType.Percent;
                _tableLayoutPanel.RowStyles[i].Height = 30;
            }
            for (int i = 0; i < 2; i++)
            {
                _tableLayoutPanel.ColumnStyles.Add(new ColumnStyle());
                _tableLayoutPanel.ColumnStyles[i].SizeType = SizeType.Percent;
                _tableLayoutPanel.ColumnStyles[i].Width = 30;
            }
        }

        private void SetLabelStyles()
        {
            lblFileName.TextAlign = ContentAlignment.MiddleCenter;
            lblFileName.Anchor = (AnchorStyles.Bottom | AnchorStyles.Top | AnchorStyles.Right);
            lblWidth.TextAlign = ContentAlignment.MiddleCenter;
            lblWidth.Anchor = (AnchorStyles.Bottom | AnchorStyles.Top | AnchorStyles.Right);
            lblHeight.TextAlign = ContentAlignment.MiddleCenter;
            lblHeight.Anchor = (AnchorStyles.Bottom | AnchorStyles.Top | AnchorStyles.Right);
        }

        private void AddControls()
        {
            _tableLayoutPanel.Controls.Add(lblFileName, 0, 0);
            _tableLayoutPanel.Controls.Add(lblWidth, 0, 1);
            _tableLayoutPanel.Controls.Add(lblHeight, 0, 2);
            _tableLayoutPanel.Controls.Add(txtFileName, 1, 0);
            _tableLayoutPanel.Controls.Add(txtWidth, 1, 1);
            _tableLayoutPanel.Controls.Add(txtHeight, 1, 2);
            _tableLayoutPanel.Controls.Add(btnOK, 0, 3);
            _tableLayoutPanel.Controls.Add(btnCancel, 1, 3);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _canceled = true;
            Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            _canceled = false;
            Close();
            Lab3_Paint.Paint.FileName = FileName;
        }
    }
}
