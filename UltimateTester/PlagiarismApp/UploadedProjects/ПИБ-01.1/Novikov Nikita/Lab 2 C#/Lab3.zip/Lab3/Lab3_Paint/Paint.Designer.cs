﻿namespace Lab3_Paint
{
    partial class Paint
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Paint));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newBlankToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsPanel = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPickColour = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnColour16 = new System.Windows.Forms.Button();
            this.btnColour15 = new System.Windows.Forms.Button();
            this.btnColour14 = new System.Windows.Forms.Button();
            this.btnColour13 = new System.Windows.Forms.Button();
            this.btnColour12 = new System.Windows.Forms.Button();
            this.btnColour11 = new System.Windows.Forms.Button();
            this.btnColour10 = new System.Windows.Forms.Button();
            this.btnColour9 = new System.Windows.Forms.Button();
            this.btnColour8 = new System.Windows.Forms.Button();
            this.btnColour7 = new System.Windows.Forms.Button();
            this.btnColour6 = new System.Windows.Forms.Button();
            this.btnColour5 = new System.Windows.Forms.Button();
            this.btnColour4 = new System.Windows.Forms.Button();
            this.btnColour3 = new System.Windows.Forms.Button();
            this.btnColour2 = new System.Windows.Forms.Button();
            this.btnColour1 = new System.Windows.Forms.Button();
            this.brushSelection = new System.Windows.Forms.GroupBox();
            this.buttonDrawFlowerBrush = new System.Windows.Forms.Button();
            this.buttonErase = new System.Windows.Forms.Button();
            this.buttonCircleSprayBrush = new System.Windows.Forms.Button();
            this.buttonDrawCircle = new System.Windows.Forms.Button();
            this.buttonDrawSquareSpray = new System.Windows.Forms.Button();
            this.buttonDrawSnowflake = new System.Windows.Forms.Button();
            this.buttonDrawCircumference = new System.Windows.Forms.Button();
            this.buttonDrawSquare = new System.Windows.Forms.Button();
            this.brushSizeTrackBar = new System.Windows.Forms.TrackBar();
            this.drawPanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.saveFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.openFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.menuStrip1.SuspendLayout();
            this.toolsPanel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.brushSelection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.brushSizeTrackBar)).BeginInit();
            this.drawPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(671, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newBlankToolStripMenuItem,
            this.newToolStripMenuItem,
            this.toolStripMenuItem1,
            this.openFileToolStripMenuItem,
            this.toolStripMenuItem2,
            this.saveFileToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "Create...";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // newBlankToolStripMenuItem
            // 
            this.newBlankToolStripMenuItem.Name = "newBlankToolStripMenuItem";
            this.newBlankToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newBlankToolStripMenuItem.Text = "Create a blank";
            this.newBlankToolStripMenuItem.Click += new System.EventHandler(this.newBlankToolStripMenuItem_Click);
            // 
            // toolsPanel
            // 
            this.toolsPanel.Controls.Add(this.groupBox2);
            this.toolsPanel.Controls.Add(this.groupBox1);
            this.toolsPanel.Controls.Add(this.brushSelection);
            this.toolsPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.toolsPanel.Location = new System.Drawing.Point(550, 24);
            this.toolsPanel.Name = "toolsPanel";
            this.toolsPanel.Size = new System.Drawing.Size(121, 457);
            this.toolsPanel.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnPickColour);
            this.groupBox2.Location = new System.Drawing.Point(0, 276);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(121, 44);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Current colour";
            // 
            // btnPickColour
            // 
            this.btnPickColour.BackColor = System.Drawing.Color.Black;
            this.btnPickColour.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPickColour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPickColour.Location = new System.Drawing.Point(10, 19);
            this.btnPickColour.Name = "btnPickColour";
            this.btnPickColour.Size = new System.Drawing.Size(98, 14);
            this.btnPickColour.TabIndex = 1;
            this.btnPickColour.UseVisualStyleBackColor = false;
            this.btnPickColour.Click += new System.EventHandler(this.btnPickColour_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnColour16);
            this.groupBox1.Controls.Add(this.btnColour15);
            this.groupBox1.Controls.Add(this.btnColour14);
            this.groupBox1.Controls.Add(this.btnColour13);
            this.groupBox1.Controls.Add(this.btnColour12);
            this.groupBox1.Controls.Add(this.btnColour11);
            this.groupBox1.Controls.Add(this.btnColour10);
            this.groupBox1.Controls.Add(this.btnColour9);
            this.groupBox1.Controls.Add(this.btnColour8);
            this.groupBox1.Controls.Add(this.btnColour7);
            this.groupBox1.Controls.Add(this.btnColour6);
            this.groupBox1.Controls.Add(this.btnColour5);
            this.groupBox1.Controls.Add(this.btnColour4);
            this.groupBox1.Controls.Add(this.btnColour3);
            this.groupBox1.Controls.Add(this.btnColour2);
            this.groupBox1.Controls.Add(this.btnColour1);
            this.groupBox1.Location = new System.Drawing.Point(0, 326);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(118, 128);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Palette";
            // 
            // btnColour16
            // 
            this.btnColour16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour16.Location = new System.Drawing.Point(88, 98);
            this.btnColour16.Name = "btnColour16";
            this.btnColour16.Size = new System.Drawing.Size(20, 20);
            this.btnColour16.TabIndex = 15;
            this.btnColour16.UseVisualStyleBackColor = true;
            this.btnColour16.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour15
            // 
            this.btnColour15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour15.Location = new System.Drawing.Point(62, 98);
            this.btnColour15.Name = "btnColour15";
            this.btnColour15.Size = new System.Drawing.Size(20, 20);
            this.btnColour15.TabIndex = 14;
            this.btnColour15.UseVisualStyleBackColor = true;
            this.btnColour15.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour14
            // 
            this.btnColour14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour14.Location = new System.Drawing.Point(36, 98);
            this.btnColour14.Name = "btnColour14";
            this.btnColour14.Size = new System.Drawing.Size(20, 20);
            this.btnColour14.TabIndex = 13;
            this.btnColour14.UseVisualStyleBackColor = true;
            this.btnColour14.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour13
            // 
            this.btnColour13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour13.Location = new System.Drawing.Point(10, 98);
            this.btnColour13.Name = "btnColour13";
            this.btnColour13.Size = new System.Drawing.Size(20, 20);
            this.btnColour13.TabIndex = 12;
            this.btnColour13.UseVisualStyleBackColor = true;
            this.btnColour13.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour12
            // 
            this.btnColour12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour12.Location = new System.Drawing.Point(88, 72);
            this.btnColour12.Name = "btnColour12";
            this.btnColour12.Size = new System.Drawing.Size(20, 20);
            this.btnColour12.TabIndex = 11;
            this.btnColour12.UseVisualStyleBackColor = true;
            this.btnColour12.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour11
            // 
            this.btnColour11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour11.Location = new System.Drawing.Point(62, 72);
            this.btnColour11.Name = "btnColour11";
            this.btnColour11.Size = new System.Drawing.Size(20, 20);
            this.btnColour11.TabIndex = 10;
            this.btnColour11.UseVisualStyleBackColor = true;
            this.btnColour11.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour10
            // 
            this.btnColour10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour10.Location = new System.Drawing.Point(36, 72);
            this.btnColour10.Name = "btnColour10";
            this.btnColour10.Size = new System.Drawing.Size(20, 20);
            this.btnColour10.TabIndex = 9;
            this.btnColour10.UseVisualStyleBackColor = true;
            this.btnColour10.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour9
            // 
            this.btnColour9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour9.Location = new System.Drawing.Point(10, 72);
            this.btnColour9.Name = "btnColour9";
            this.btnColour9.Size = new System.Drawing.Size(20, 20);
            this.btnColour9.TabIndex = 8;
            this.btnColour9.UseVisualStyleBackColor = true;
            this.btnColour9.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour8
            // 
            this.btnColour8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour8.Location = new System.Drawing.Point(88, 46);
            this.btnColour8.Name = "btnColour8";
            this.btnColour8.Size = new System.Drawing.Size(20, 20);
            this.btnColour8.TabIndex = 7;
            this.btnColour8.UseVisualStyleBackColor = true;
            this.btnColour8.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour7
            // 
            this.btnColour7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour7.Location = new System.Drawing.Point(62, 46);
            this.btnColour7.Name = "btnColour7";
            this.btnColour7.Size = new System.Drawing.Size(20, 20);
            this.btnColour7.TabIndex = 6;
            this.btnColour7.UseVisualStyleBackColor = true;
            this.btnColour7.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour6
            // 
            this.btnColour6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour6.Location = new System.Drawing.Point(36, 46);
            this.btnColour6.Name = "btnColour6";
            this.btnColour6.Size = new System.Drawing.Size(20, 20);
            this.btnColour6.TabIndex = 5;
            this.btnColour6.UseVisualStyleBackColor = true;
            this.btnColour6.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour5
            // 
            this.btnColour5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour5.Location = new System.Drawing.Point(10, 46);
            this.btnColour5.Name = "btnColour5";
            this.btnColour5.Size = new System.Drawing.Size(20, 20);
            this.btnColour5.TabIndex = 4;
            this.btnColour5.UseVisualStyleBackColor = true;
            this.btnColour5.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour4
            // 
            this.btnColour4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour4.Location = new System.Drawing.Point(88, 20);
            this.btnColour4.Name = "btnColour4";
            this.btnColour4.Size = new System.Drawing.Size(20, 20);
            this.btnColour4.TabIndex = 3;
            this.btnColour4.UseVisualStyleBackColor = true;
            this.btnColour4.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour3
            // 
            this.btnColour3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour3.Location = new System.Drawing.Point(62, 20);
            this.btnColour3.Name = "btnColour3";
            this.btnColour3.Size = new System.Drawing.Size(20, 20);
            this.btnColour3.TabIndex = 2;
            this.btnColour3.UseVisualStyleBackColor = true;
            this.btnColour3.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour2
            // 
            this.btnColour2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour2.Location = new System.Drawing.Point(36, 20);
            this.btnColour2.Name = "btnColour2";
            this.btnColour2.Size = new System.Drawing.Size(20, 20);
            this.btnColour2.TabIndex = 1;
            this.btnColour2.UseVisualStyleBackColor = true;
            this.btnColour2.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // btnColour1
            // 
            this.btnColour1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColour1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColour1.Location = new System.Drawing.Point(10, 20);
            this.btnColour1.Name = "btnColour1";
            this.btnColour1.Size = new System.Drawing.Size(20, 20);
            this.btnColour1.TabIndex = 0;
            this.btnColour1.UseVisualStyleBackColor = true;
            this.btnColour1.Click += new System.EventHandler(this.ChangeBrushColour);
            // 
            // brushSelection
            // 
            this.brushSelection.Controls.Add(this.buttonDrawFlowerBrush);
            this.brushSelection.Controls.Add(this.buttonErase);
            this.brushSelection.Controls.Add(this.buttonCircleSprayBrush);
            this.brushSelection.Controls.Add(this.buttonDrawCircle);
            this.brushSelection.Controls.Add(this.buttonDrawSquareSpray);
            this.brushSelection.Controls.Add(this.buttonDrawSnowflake);
            this.brushSelection.Controls.Add(this.buttonDrawCircumference);
            this.brushSelection.Controls.Add(this.buttonDrawSquare);
            this.brushSelection.Controls.Add(this.brushSizeTrackBar);
            this.brushSelection.Dock = System.Windows.Forms.DockStyle.Top;
            this.brushSelection.Location = new System.Drawing.Point(0, 0);
            this.brushSelection.Name = "brushSelection";
            this.brushSelection.Size = new System.Drawing.Size(121, 270);
            this.brushSelection.TabIndex = 0;
            this.brushSelection.TabStop = false;
            this.brushSelection.Text = "Brush";
            // 
            // buttonDrawFlowerBrush
            // 
            this.buttonDrawFlowerBrush.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDrawFlowerBrush.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrawFlowerBrush.Image = global::Lab3_Paint.Properties.Resources.Flower;
            this.buttonDrawFlowerBrush.Location = new System.Drawing.Point(21, 171);
            this.buttonDrawFlowerBrush.Name = "buttonDrawFlowerBrush";
            this.buttonDrawFlowerBrush.Size = new System.Drawing.Size(35, 35);
            this.buttonDrawFlowerBrush.TabIndex = 8;
            this.buttonDrawFlowerBrush.UseVisualStyleBackColor = true;
            this.buttonDrawFlowerBrush.Click += new System.EventHandler(this.buttonDrawFlowerBrush_Click);
            // 
            // buttonErase
            // 
            this.buttonErase.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonErase.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonErase.Image = global::Lab3_Paint.Properties.Resources.Eraser;
            this.buttonErase.Location = new System.Drawing.Point(21, 225);
            this.buttonErase.Name = "buttonErase";
            this.buttonErase.Size = new System.Drawing.Size(35, 35);
            this.buttonErase.TabIndex = 7;
            this.buttonErase.UseVisualStyleBackColor = true;
            this.buttonErase.Click += new System.EventHandler(this.buttonErase_Click);
            // 
            // buttonCircleSprayBrush
            // 
            this.buttonCircleSprayBrush.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCircleSprayBrush.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCircleSprayBrush.Image = global::Lab3_Paint.Properties.Resources.Round_spray;
            this.buttonCircleSprayBrush.Location = new System.Drawing.Point(62, 130);
            this.buttonCircleSprayBrush.Name = "buttonCircleSprayBrush";
            this.buttonCircleSprayBrush.Size = new System.Drawing.Size(35, 35);
            this.buttonCircleSprayBrush.TabIndex = 6;
            this.buttonCircleSprayBrush.UseVisualStyleBackColor = true;
            this.buttonCircleSprayBrush.Click += new System.EventHandler(this.buttonCircleSprayBrush_Click);
            // 
            // buttonDrawCircle
            // 
            this.buttonDrawCircle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDrawCircle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrawCircle.Image = global::Lab3_Paint.Properties.Resources.Circle;
            this.buttonDrawCircle.Location = new System.Drawing.Point(62, 48);
            this.buttonDrawCircle.Name = "buttonDrawCircle";
            this.buttonDrawCircle.Size = new System.Drawing.Size(35, 35);
            this.buttonDrawCircle.TabIndex = 5;
            this.buttonDrawCircle.UseVisualStyleBackColor = true;
            this.buttonDrawCircle.Click += new System.EventHandler(this.buttonDrawCircle_Click);
            // 
            // buttonDrawSquareSpray
            // 
            this.buttonDrawSquareSpray.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDrawSquareSpray.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrawSquareSpray.Image = global::Lab3_Paint.Properties.Resources.Simple_spray;
            this.buttonDrawSquareSpray.Location = new System.Drawing.Point(21, 130);
            this.buttonDrawSquareSpray.Name = "buttonDrawSquareSpray";
            this.buttonDrawSquareSpray.Size = new System.Drawing.Size(35, 35);
            this.buttonDrawSquareSpray.TabIndex = 4;
            this.buttonDrawSquareSpray.UseVisualStyleBackColor = true;
            this.buttonDrawSquareSpray.Click += new System.EventHandler(this.buttonDrawSquareSpray_Click);
            // 
            // buttonDrawSnowflake
            // 
            this.buttonDrawSnowflake.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDrawSnowflake.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrawSnowflake.Image = global::Lab3_Paint.Properties.Resources.Snowflake;
            this.buttonDrawSnowflake.Location = new System.Drawing.Point(62, 89);
            this.buttonDrawSnowflake.Name = "buttonDrawSnowflake";
            this.buttonDrawSnowflake.Size = new System.Drawing.Size(35, 35);
            this.buttonDrawSnowflake.TabIndex = 3;
            this.buttonDrawSnowflake.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonDrawSnowflake.UseVisualStyleBackColor = true;
            this.buttonDrawSnowflake.Click += new System.EventHandler(this.buttonDrawSnowflake_Click);
            // 
            // buttonDrawCircumference
            // 
            this.buttonDrawCircumference.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDrawCircumference.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrawCircumference.Image = global::Lab3_Paint.Properties.Resources.Circumference;
            this.buttonDrawCircumference.Location = new System.Drawing.Point(21, 89);
            this.buttonDrawCircumference.Name = "buttonDrawCircumference";
            this.buttonDrawCircumference.Size = new System.Drawing.Size(35, 35);
            this.buttonDrawCircumference.TabIndex = 2;
            this.buttonDrawCircumference.UseVisualStyleBackColor = true;
            this.buttonDrawCircumference.Click += new System.EventHandler(this.buttonDrawCircumference_Click);
            // 
            // buttonDrawSquare
            // 
            this.buttonDrawSquare.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDrawSquare.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDrawSquare.Image = ((System.Drawing.Image)(resources.GetObject("buttonDrawSquare.Image")));
            this.buttonDrawSquare.Location = new System.Drawing.Point(21, 48);
            this.buttonDrawSquare.Name = "buttonDrawSquare";
            this.buttonDrawSquare.Size = new System.Drawing.Size(35, 35);
            this.buttonDrawSquare.TabIndex = 1;
            this.buttonDrawSquare.UseVisualStyleBackColor = true;
            this.buttonDrawSquare.Click += new System.EventHandler(this.buttonDrawSquare_Click);
            // 
            // brushSizeTrackBar
            // 
            this.brushSizeTrackBar.AutoSize = false;
            this.brushSizeTrackBar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.brushSizeTrackBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.brushSizeTrackBar.LargeChange = 20;
            this.brushSizeTrackBar.Location = new System.Drawing.Point(3, 16);
            this.brushSizeTrackBar.Maximum = 80;
            this.brushSizeTrackBar.Minimum = 1;
            this.brushSizeTrackBar.Name = "brushSizeTrackBar";
            this.brushSizeTrackBar.Size = new System.Drawing.Size(115, 26);
            this.brushSizeTrackBar.SmallChange = 4;
            this.brushSizeTrackBar.TabIndex = 0;
            this.brushSizeTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.brushSizeTrackBar.Value = 5;
            this.brushSizeTrackBar.Scroll += new System.EventHandler(this.brushSizeTrackBar_Scroll);
            // 
            // drawPanel
            // 
            this.drawPanel.AutoScroll = true;
            this.drawPanel.Controls.Add(this.pictureBox1);
            this.drawPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.drawPanel.Location = new System.Drawing.Point(0, 24);
            this.drawPanel.Name = "drawPanel";
            this.drawPanel.Size = new System.Drawing.Size(550, 457);
            this.drawPanel.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Silver;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(550, 455);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // colorDialog1
            // 
            this.colorDialog1.FullOpen = true;
            this.colorDialog1.ShowHelp = true;
            this.colorDialog1.SolidColorOnly = true;
            // 
            // saveFileToolStripMenuItem
            // 
            this.saveFileToolStripMenuItem.Name = "saveFileToolStripMenuItem";
            this.saveFileToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveFileToolStripMenuItem.Text = "Save as...";
            this.saveFileToolStripMenuItem.Click += new System.EventHandler(this.saveFileToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(177, 6);
            // 
            // openFileToolStripMenuItem
            // 
            this.openFileToolStripMenuItem.Name = "openFileToolStripMenuItem";
            this.openFileToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.openFileToolStripMenuItem.Text = "Open...";
            this.openFileToolStripMenuItem.Click += new System.EventHandler(this.openFileToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(177, 6);
            // 
            // Paint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(671, 481);
            this.Controls.Add(this.drawPanel);
            this.Controls.Add(this.toolsPanel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Paint";
            this.Text = "Paint";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolsPanel.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.brushSelection.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.brushSizeTrackBar)).EndInit();
            this.drawPanel.ResumeLayout(false);
            this.drawPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.Panel toolsPanel;
        private System.Windows.Forms.GroupBox brushSelection;
        private System.Windows.Forms.Panel drawPanel;
        private System.Windows.Forms.TrackBar brushSizeTrackBar;
        private System.Windows.Forms.Button buttonDrawSnowflake;
        private System.Windows.Forms.Button buttonDrawCircumference;
        private System.Windows.Forms.Button buttonDrawSquare;
        private System.Windows.Forms.Button buttonDrawSquareSpray;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.Button buttonDrawCircle;
        private System.Windows.Forms.Button buttonCircleSprayBrush;
        private System.Windows.Forms.Button buttonErase;
        private System.Windows.Forms.Button buttonDrawFlowerBrush;
        private System.Windows.Forms.Button btnPickColour;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnColour1;
        private System.Windows.Forms.Button btnColour8;
        private System.Windows.Forms.Button btnColour7;
        private System.Windows.Forms.Button btnColour6;
        private System.Windows.Forms.Button btnColour5;
        private System.Windows.Forms.Button btnColour4;
        private System.Windows.Forms.Button btnColour3;
        private System.Windows.Forms.Button btnColour2;
        private System.Windows.Forms.Button btnColour12;
        private System.Windows.Forms.Button btnColour11;
        private System.Windows.Forms.Button btnColour10;
        private System.Windows.Forms.Button btnColour9;
        private System.Windows.Forms.Button btnColour16;
        private System.Windows.Forms.Button btnColour15;
        private System.Windows.Forms.Button btnColour14;
        private System.Windows.Forms.Button btnColour13;
        private System.Windows.Forms.ToolStripMenuItem newBlankToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem openFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
    }
}

