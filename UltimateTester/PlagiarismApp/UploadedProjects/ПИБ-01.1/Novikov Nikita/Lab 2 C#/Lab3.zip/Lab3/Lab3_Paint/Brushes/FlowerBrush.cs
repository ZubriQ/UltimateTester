﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Paint
{
    //  6:  p = 3 sqrt (cos(3 fi) )
    internal class FlowerBrush : Brush
    {
        public FlowerBrush(Color brushColour, int size) : base(brushColour, size) { }

        public override void Draw(Bitmap image, int xc, int yc)
        {
            double hypotenuse;
            int newX, newY;
            int coefficient = Size * 3;

            for (double fi = 0; fi <= 720; fi += 0.1)
            {
                hypotenuse = coefficient * Math.Sqrt(Math.Abs(Math.Cos(3 * fi)));
                newX = (int)(xc + Math.Cos(fi) * hypotenuse);
                newY = (int)(yc + Math.Sin(fi) * hypotenuse);

                SetPixel(newX, newY, image);
            }
        }
    }
}
