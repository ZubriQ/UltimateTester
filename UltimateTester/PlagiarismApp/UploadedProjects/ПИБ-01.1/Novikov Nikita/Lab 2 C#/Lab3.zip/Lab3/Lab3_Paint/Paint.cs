﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_Paint
{
    public partial class Paint : Form
    {
        public static string FileName { get; set; } = "NoImageName";

        // Blank image colour.
        Color _defaultColour => Color.White;

        int _x;
        int _y;
        bool _mouseClicked = false;

        // Drawing brush colour.
        Color _selectedColour => colorDialog1.Color;

        int SelectedSize
        {
            get { return brushSizeTrackBar.Value; }
            set { brushSizeTrackBar.Value = value; }
        }
        Brush _selectedBrush;

        public Paint()
        {
            InitializeComponent();
            InitializePalette();
            CreateBlankImage(800, 600);
        }

        private void CreateBlankImage(int width, int height)
        {
            var oldImage = pictureBox1.Image;

            if (width < 1 || height < 1) 
                MessageBox.Show("The image is too small.", "Error");
            else if (width > 4000 || height > 4000)
                MessageBox.Show("The image is too large.", "Error");
            else if (width > 0 && height > 0)
            {
                var bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);

                for (int i = 0; i < width; i++)
                    for (int j = 0; j < height; j++)
                        bmp.SetPixel(i, j, _defaultColour);

                pictureBox1.Image = bmp;
                if (oldImage != null)
                    oldImage.Dispose();
            }
        }


        #region Brush buttons
        private void buttonDrawSquare_Click(object sender, EventArgs e)
        {
            _selectedBrush = new QuadBrush(_selectedColour, SelectedSize);
        }

        private void buttonDrawCircle_Click(object sender, EventArgs e)
        {
            _selectedBrush = new CircleBrush(_selectedColour, SelectedSize);
        }

        private void buttonDrawCircumference_Click(object sender, EventArgs e)
        {
            _selectedBrush = new CircumferenceBrush(_selectedColour, SelectedSize);
        }

        private void buttonDrawSnowflake_Click(object sender, EventArgs e)
        {
            _selectedBrush = new SnowflakeBrush(_selectedColour, SelectedSize);
        }

        private void buttonDrawSquareSpray_Click(object sender, EventArgs e)
        {
            _selectedBrush = new SquareSprayBrush(_selectedColour, SelectedSize);
        }

        private void buttonCircleSprayBrush_Click(object sender, EventArgs e)
        {
            _selectedBrush = new CircleSprayBrush(_selectedColour, SelectedSize);
        }

        private void buttonErase_Click(object sender, EventArgs e)
        {
            _selectedBrush = new Eraser(_selectedColour, SelectedSize);
        }

        private void buttonDrawFlowerBrush_Click(object sender, EventArgs e)
        {
            _selectedBrush = new FlowerBrush(_selectedColour, SelectedSize);
        }
        #endregion


        #region Picture box
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            _mouseClicked = false;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (_selectedBrush == null)
                return;

            try
            {
                _selectedBrush.Draw(pictureBox1.Image as Bitmap, _x, _y);
                _mouseClicked = true;
            }
            finally
            {
                pictureBox1.Refresh();
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            _x = e.X > 0 ? e.X : 0;
            _y = e.Y > 0 ? e.Y : 0;

            try
            {
                if (_mouseClicked)
                {
                    _selectedBrush.Draw(pictureBox1.Image as Bitmap, _x, _y);
                }
            }
            finally
            {
                pictureBox1.Refresh();
            }
        }
        #endregion


        private void brushSizeTrackBar_Scroll(object sender, EventArgs e)
        {
            SelectedSize = brushSizeTrackBar.Value;
            if (_selectedBrush != null)
                _selectedBrush.Size = SelectedSize;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateImageForm form = new CreateImageForm();
            form.ShowDialog();
            if (form.Canceled == false)
                CreateBlankImage(form.W, form.H);
        }

        private void newBlankToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateBlankImage(800, 600);
        }

        private void btnPickColour_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                if (_selectedBrush != null)
                    _selectedBrush.BrushColour = colorDialog1.Color;
                btnPickColour.BackColor = colorDialog1.Color;
            }
        }

        private void ChangeBrushColour(object sender, EventArgs e)
        {
            var colour = (sender as Button).BackColor;
            if (_selectedBrush != null)
                _selectedBrush.BrushColour = colour;
            btnPickColour.BackColor = colour;
            colorDialog1.Color = colour;
        }

        private void InitializePalette()
        {
            btnColour1.BackColor = Color.Black;
            btnColour5.BackColor = Color.White;
            btnColour2.BackColor = Color.Gray;
            btnColour6.BackColor = Color.LightGray;
            // Red.
            btnColour3.BackColor = Color.FromArgb(255, 25, 25);
            btnColour7.BackColor = Color.FromArgb(255, 155, 155);
            // Orange.
            btnColour4.BackColor = Color.FromArgb(255, 128, 0);
            btnColour8.BackColor = Color.FromArgb(255, 178, 102);
            // Green.
            btnColour9.BackColor = Color.FromArgb(25, 255, 25);
            btnColour13.BackColor = Color.FromArgb(155, 255, 155);
            // Cyan
            btnColour10.BackColor = Color.FromArgb(0, 255, 255);
            btnColour14.BackColor = Color.FromArgb(155, 255, 255);
            // Blue
            btnColour11.BackColor = Color.FromArgb(55, 55, 255);
            btnColour15.BackColor = Color.FromArgb(102, 102, 255);
            // Magenta
            btnColour12.BackColor = Color.FromArgb(255, 0, 255);
            btnColour16.BackColor = Color.FromArgb(255, 155, 255);
        }

        private void saveFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Jpeg Files|*.jpeg";
            dialog.FileName = FileName;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                int width = Convert.ToInt32(pictureBox1.Width);
                int height = Convert.ToInt32(pictureBox1.Height);
                Bitmap bmp = new Bitmap(width, height);
                pictureBox1.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));
                bmp.Save(dialog.FileName, ImageFormat.Jpeg);
            }
        }

        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(open.FileName);
                FileName = open.FileName;
            }
        }
    }
}
