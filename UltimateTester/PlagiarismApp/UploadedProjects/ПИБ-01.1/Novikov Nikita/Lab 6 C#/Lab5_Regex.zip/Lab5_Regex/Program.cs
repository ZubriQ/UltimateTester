﻿using System;
using System.IO;

namespace Lab5_Regex
{
    internal class Program
    {
        internal static FileManager FileWorker;
        static void Main(string[] args)
        {
            RunLab5();

            Console.ReadLine();
        }

        private static void RunLab5()
        {
            FileWorker = new FileManager();
            SetStream("regex.txt");
            FileWorker.ReadFile();


            Message("\n\tTask 1. Check for aaaaa or a aa a or a:");
            FileWorker.MatchValues("aaaaa|a aa a|a");


            Message("\n\tTask 2. Check Digits & Letters:");
            FileWorker.MatchValues(@"\w{6,}");  // Or @"^\w{6,}$"


            Message("\n\tTask 3. Check & output correct E-mails:");
            string emailPattern = @"^[a-zA-Z][a-zA-Z0-9\-_+.]{0,254}\@(([a-zA-Z][a-zA-Z0-9\-]{0,}))(\.[a-zA-Z]{2,})+$";
            FileWorker.MatchStrings(emailPattern);


            Message("\n\tTask 4. Variant C.");
            string pattern = @"((?<second_name>[а-яА-Я]{2,})\s+(?<first_name>[а-яА-Я]{2,}))(\s+(?<patronymic>[а-яА-Я]{2,}))?\,\s+(?<age>[1-9]\d{0,2})\s+(год|лет)\,(\s+)?(г\.\s+)?(г.)?(?<city>[а-яА-Я]{2,})";
            FileWorker.GetPersonalData(pattern);


            Message("\n\tTask 5. Lab 5 - testData.xml");
            // a: Task 4.
            // b: ^\d+.                                     Replace by: ""
            // c: ^(<)?(\s+)?(<\w+\>)([^<]+)(\<\/\w+\>)     Replace by: "  $3$4$5"
            // d: \<(\w+)\>([^<]+)\<\/(\w+)\>               Replace by: "<$1>$2</$1>"


            Message("\n\tLab 5. Additional task 1.");
            SetStream("additional_task1.txt");
            FileWorker.ReadFile();
            string shopPattern = @"(?<weight>(?:\d+\.)?(?:[0-9]+)?[1-9]{1}(?:[0-9]+)?)(?:\s+)?кг\.?(?:\s+)?(?<name>[а-яА-Я]+)(?:\s+)?\-(?:\s+)?(?<price>[1-9][0-9]{0,8})(?:\s+)?руб\.?";
            FileWorker.GetShopPriceList(shopPattern);


            Message("\n\tLab 5. Additional task 2.");
            SetStream("additional_task2.txt");
            FileWorker.ReadFile();
            //string websitePattern = @"((http|https|ftp):(?:\/\/|\\\\))?(?:www\.)?([\w\-_]+)(\.[\w\-_]+){1,4}";
            string websitePattern = @"(?<protocol>(?:http|https|ftp):\/\/)?(?:www)?(?<domain>[\w_]+[\w\-_]+(?:\.[\w_]+[\w\-_]+){1,4})";
            FileWorker.GetURLs(websitePattern, "savedUrls.txt");
        }

        private static void Message(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(msg);
            Console.ForegroundColor= ConsoleColor.White;
        }

        private static void SetStream(string fileName)
        {
            StreamReader sr = new StreamReader(new FileStream(
                Path.Combine(Environment.CurrentDirectory, fileName),
                FileMode.Open));
            FileWorker.SetStream(sr);
        }
    }
}
