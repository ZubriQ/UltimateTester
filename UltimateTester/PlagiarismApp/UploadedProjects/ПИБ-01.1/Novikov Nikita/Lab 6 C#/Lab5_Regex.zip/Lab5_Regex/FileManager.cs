﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Lab5_Regex
{
    internal class FileManager
    {
        private StreamReader _stream;

        public string[] Strings { get; private set; }

        public FileManager(StreamReader stream)
        {
            _stream = stream;
        }

        public FileManager() { }

        public void SetStream(StreamReader stream)
        {
            if (_stream != null)
                _stream.Close();
            _stream = stream;
        }

        public void ReadFile()
        {
            Message("Reading the file...");
            List<string> strings = new List<string>();

            int i = 0;
            while (!_stream.EndOfStream)
            {
                strings.Add(_stream.ReadLine());
                Console.WriteLine(strings[i]);
                i++;
            }

            Strings = strings.ToArray();
            Message("The reading has ended.");
        }

        public void GetURLs(string pattern, string saveAs)
        {
            Message($"Checking the strings (Pattern: {pattern}) ...");

            Regex regex = new Regex(pattern);
            List<string> urls = new List<string>();
            OutputURLs(regex, urls);
            SaveURLs(urls, saveAs);

            Message("The checking has ended.");
        }

        private void OutputURLs(Regex regex, List<string> urls)
        {
            int strLength = 0;
            string record;
            for (int i = 0; i < Strings.Length; i++)
                if (regex.IsMatch(Strings[i]))
                {
                    Match match = regex.Match(Strings[i]);

                    while (match.Success)
                    {
                        record = $"Index : {strLength + match.Index};\t Site : {match.Value}";
                        urls.Add(record);
                        Console.WriteLine(record);

                        match = match.NextMatch();
                    }
                    strLength += Strings[i].Length;
                }
        }

        private void SaveURLs(List<string> urls, string saveAs)
        {
            StreamWriter sw = new StreamWriter(new FileStream(
    Path.Combine(Environment.CurrentDirectory, saveAs),
    FileMode.Create));
            for (int i = 0; i < urls.Count; i++)
            {
                sw.WriteLine(urls[i]);
            }
            sw.Close();
        }

        // Additional task 1
        public void GetShopPriceList(string pattern)
        {
            Message($"Checking the strings (Pattern: {pattern}) ...");
            Regex regex = new Regex(pattern);

            for (int i = 0; i < Strings.Length; i++)
                if (regex.IsMatch(Strings[i]))
                {
                    // Find and output all matches in a string.
                    PrintShopGoods(regex, Strings[i]);
                }
            Message("The checking has ended.");
        }

        private void PrintShopGoods(Regex regex, string s)
        {
            Match match = regex.Match(s);
            double weight, price;
            while (match.Success)
            {
                Double.TryParse(match.Groups["price"].ToString(), out price);
                Double.TryParse(match.Groups["weight"].ToString(), out weight);

                Console.WriteLine($"{match.Groups["name"]} - " +
                    $"{Math.Round(price / weight, 2)} руб/кг");
                // To the next match.
                match = match.NextMatch();
            }
        }

        // Task 4
        public void GetPersonalData(string pattern)
        {
            Message($"Checking the strings (Pattern: {pattern}) ...");
            Regex regex = new Regex(pattern);
            int matchCount = 0;

            for (int i = 0; i < Strings.Length; i++)
                if (regex.IsMatch(Strings[i]))
                {
                    // Find and output all matches in a string.
                    OutputPersonInfo(regex, Strings[i], ref matchCount);
                }
            Message("The checking has ended.");
            Message($"Match Count = {matchCount}");
        }

        private void OutputPersonInfo(Regex regex, string s, ref int count)
        {
            Match match = regex.Match(s);
            while (match.Success)
            {
                count++;
                Console.WriteLine($"Second name = {match.Groups["second_name"]}," +
                    $" Age = {match.Groups["age"]}, City = {match.Groups["city"]}.");
                // To the next match.
                match = match.NextMatch();
            }
        }

        /// <summary>
        /// Outputs every matched substring of a string.
        /// </summary>
        /// <param name="pattern">Regex's pattern.</param>
        public void MatchValues(string pattern)
        {
            Message($"Checking the strings (Pattern: {pattern}) ...");
            Regex regex = new Regex(pattern);
            int matchCount = 0;

            for (int i = 0; i < Strings.Length; i++)
                if (regex.IsMatch(Strings[i]))
                {
                    Message($"Matches in a string {i}: ");
                    // Find and output all matches in a string.
                    Match(regex, Strings[i], ref matchCount);
                }
            Message("The checking has ended.");
            Message($"Match Count = {matchCount}");
        }

        private void Match(Regex regex, string s, ref int count)
        {
            Match match = regex.Match(s);
            while (match.Success)
            {
                count++;
                Console.WriteLine(match.Value);
                // To the next match.
                match = match.NextMatch();
            }
        }

        /// <summary>
        /// Outputs just a whole string if matched.
        /// </summary>
        /// <param name="pattern">Regex's pattern.</param>
        public void MatchStrings(string pattern)
        {
            Message("Checking the strings...");
            Regex regex = new Regex(pattern);

            for (int i = 0; i < Strings.Length; i++)
                if (regex.IsMatch(Strings[i]))
                {
                    Console.WriteLine(Strings[i]);
                }
            Message("The checking has ended.");
        }

        private void Message(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            StringBuilder sb = new StringBuilder();
            sb.Append("\t[System]: ");
            sb.Append(msg);
            Console.WriteLine(sb);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
